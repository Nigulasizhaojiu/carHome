package com.example.dllo.forum.alls;

/**
 * Created by dllo on 16/9/21.
 */
public class AllsBean {
    String allsTitle;

    public AllsBean() {

    }

    public String getAllsTitle() {
        return allsTitle;
    }

    public void setAllsTitle(String allsTitle) {
        this.allsTitle = allsTitle;
    }
}
