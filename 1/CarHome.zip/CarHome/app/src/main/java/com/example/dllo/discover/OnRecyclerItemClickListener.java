package com.example.dllo.discover;

/**
 * Created by dllo on 16/9/28.
 */
public interface OnRecyclerItemClickListener {
    public void click(int position,DiscoverBtnHeadAdapter.ViewHolder holder);
}
