package com.example.dllo.find.newcar;

import com.example.dllo.carhome.BaseFragment;
import com.example.dllo.carhome.R;

/**
 * Created by dllo on 16/9/27.
 */
public class NewFragment extends BaseFragment{
    @Override
    protected int setLayout() {
        return R.layout.oldcar_fragment;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
