package com.example.dllo.leading;

import com.example.dllo.carhome.BaseFragment;
import com.example.dllo.carhome.R;

/**
 * Created by dllo on 16/9/19.
 */
public class LeadingTwoFragment extends BaseFragment {
    @Override
    protected int setLayout() {
        return R.layout.two_leading;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
