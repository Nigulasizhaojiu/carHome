package com.example.dllo.forum.twentyfour;

import java.util.List;

/**
 * Created by dllo on 16/9/22.
 */
public class TwentyFourBean {

    /**
     * pagecount : 4
     * rowcount : 29302
     * pageindex : 1
     * list : [{"topicid":56382734,"title":"放毒，泄密，爆料，新款X80配置到底值不值那么多钱？","lastreplydate":"2016-09-22 15:14:29","postusername":"威志大汽车","replycounts":"24","ispictopic":1,"bbsid":3000,"bbsname":"奔腾X80论坛","postdate":"2016-09-21 16:50:40","memberid":3799692,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g14/M0B/F5/02/120X120_0_q87_autohomecar__wKgH5FepvXGAastnAAAY9jOXNTI817.jpg","nickname":"netoper","authseries":"","topicinfo":"废话不说，直接上图，看看新X80到底值不值那么多钱？别问我资料哪里来的，请叫我雷锋！比沃尔沃还安全，这句话确实\u201c好强硬\u201d"},{"topicid":56402302,"title":"【One night in 魔都】 Tomorrow Now/造就改变 感受科技与未来","lastreplydate":"2016-09-22 14:45:39","postusername":"inrain2","replycounts":"10","ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-22 10:27:53","memberid":3941632,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/8/dd92d8a7-1305-48b5-90b0-127b298d95ea_120X120.jpg","nickname":"inrain2","authseries":"奥迪A4L","topicinfo":""},{"topicid":56396892,"title":"博~史前文明~越~美丽灵州~之水洞沟游记(附后视镜风噪解决方案）","lastreplydate":"2016-09-22 14:18:23","postusername":"myxlove","replycounts":"221","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-22 02:36:15","memberid":30501943,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g20/M02/06/0A/120X120_0_q87_autohomecar__wKjBw1fJ2x-AVhNVAAW0ftOPZiE719.jpg","nickname":"myxlove","authseries":"博越","topicinfo":"水洞沟，一个史前文明的遗址，话不多说了，百度了一段简介，可以先阅读一下！后续高清大图奉上！水洞沟简介：  水洞沟古人类文"},{"topicid":56381305,"title":"我媳妇2次怀孕全掉了，今年7月又得了血液病","lastreplydate":"2016-09-22 15:18:04","postusername":"Levanas","replycounts":"162","ispictopic":0,"bbsid":117,"bbsname":"蒙迪欧论坛","postdate":"2016-09-21 16:11:03","memberid":10693059,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2014/9/5/064b5968-fde9-41d7-982c-c20a687baa17_120X120.jpg","nickname":"青岛大白","authseries":"蒙迪欧","topicinfo":""},{"topicid":56385500,"title":"仔细对比了奔腾B50和GL之后......","lastreplydate":"2016-09-22 15:15:26","postusername":"光看2013","replycounts":"153","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:13:41","memberid":19472650,"isvip":0,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/8/2/0b98b8a4-7cbe-41ce-abc7-445f1afcc431_120X120.jpg","nickname":"3599355abc","authseries":"","topicinfo":""},{"topicid":56388415,"title":"4s店 奔驰e200 迈巴赫套间 太霸气","lastreplydate":"2016-09-22 15:08:34","postusername":"37度的大男生","replycounts":"26","ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-09-21 20:05:31","memberid":31206289,"isvip":0,"headimg":"","nickname":"黑夜来临之时","authseries":"","topicinfo":""},{"topicid":56381556,"title":"从完全忽略到爱不释手！","lastreplydate":"2016-09-22 14:37:10","postusername":"夏日疯","replycounts":"55","ispictopic":1,"bbsid":153,"bbsname":"宝马7系论坛","postdate":"2016-09-21 16:18:45","memberid":4076984,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2013/1/2/13410165-721d-4cb0-9ab8-4bd33de1f3c0_120X120.jpg","nickname":"陈修宇","authseries":"君越","topicinfo":"其实换车的想法在14年年中就有了， 因为当时的肥越A柱确实太挡视线了（本人平时开车有点虎，但是肥越确实是部好车）。但是由"},{"topicid":56382890,"title":"大家给处女座一个建议，我洗耳恭听！","lastreplydate":"2016-09-22 14:43:19","postusername":"a遥不可及a","replycounts":"150","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:54:47","memberid":14935546,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g16/M07/51/B1/120X120_0_q87_autohomecar__wKgH5lfiSiiAXPuxAADeR-FI33g962.jpg","nickname":"贵族浪漫","authseries":"","topicinfo":""},{"topicid":56391760,"title":"媳妇不让碰，离不离？","lastreplydate":"2016-09-22 15:15:18","postusername":"pjx88","replycounts":"198","ispictopic":0,"bbsid":100002,"bbsname":"北京论坛","postdate":"2016-09-21 21:51:42","memberid":21524637,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g9/M0C/14/9D/120X120_0_q87_autohomecar__wKgH0Fe-eEiAFgt5AACsYSiQLcU110.jpg","nickname":"01v96","authseries":"","topicinfo":"媳妇不让碰，婚前就是性冷淡，我怎么办？孩子刚一岁多。二十多岁就这样，以后的日子怎么熬啊。要孩子时候就死人似的躺那，催我尽"},{"topicid":56379974,"title":"劳资开始搞安定，是我兄弟的别插手，不是我兄弟的就当看戏","lastreplydate":"2016-09-22 15:14:43","postusername":"niceking","replycounts":"201","ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 15:34:46","memberid":31336175,"isvip":0,"headimg":"","nickname":"俊行天下2016","authseries":"","topicinfo":"玩嘛，谁怕谁，第一步，明天早上十点，徐家汇汽家见，全程直播，连续剧么，大家连续下去"},{"topicid":56385984,"title":"松江街头惊现防空导弹","lastreplydate":"2016-09-22 15:11:18","postusername":"帅的抠脚","replycounts":"98","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 18:32:17","memberid":2693668,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2014/9/6/dcf30fc0-b3e5-4f44-8fe0-e0ff900503c2_120X120.jpg","nickname":"上海顶端","authseries":"宝来/宝来经典","topicinfo":"貌似往金山方向的这个路口平时警察不来"},{"topicid":56383832,"title":"女司机停车挡住生命车道  诅咒患者早点死","lastreplydate":"2016-09-22 15:06:55","postusername":"hl1997","replycounts":"69","ispictopic":1,"bbsid":46,"bbsname":"普拉多论坛","postdate":"2016-09-21 17:19:50","memberid":8933521,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g20/M15/18/76/120X120_0_q87_autohomecar__wKgFWVfVJ9yAI5HJAAFDvMS9-fc698.jpg","nickname":"举头三尺有神明1","authseries":"","topicinfo":""},{"topicid":56391531,"title":"新蓝鸟夜间偶遇新思域，就停在边上一起同框合影一下~","lastreplydate":"2016-09-22 13:59:11","postusername":"shmily晴天","replycounts":"50","ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-09-21 21:45:01","memberid":17574693,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g23/M08/99/4D/120X120_0_q87_autohomecar__wKgFXFbUgX6AabLFAABBKWd4YpQ466.jpg","nickname":"蜗牛壳吧","authseries":"LANNIA 蓝鸟","topicinfo":"新蓝鸟，新思域，昂克赛拉，都是我喜欢的车型，年轻、动感、时尚！"},{"topicid":56384331,"title":"Q5低配进化之路\u2014升级多功能方向盘最全教程（附编码故障清除）","lastreplydate":"2016-09-22 13:03:46","postusername":"潇洒老白","replycounts":"46","ispictopic":1,"bbsid":812,"bbsname":"奥迪Q5论坛","postdate":"2016-09-21 17:34:15","memberid":4604210,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2013/1/30/83e8fa07-3105-445b-9ed4-4423d5d40b9d_120X120.jpg","nickname":"潇洒老白","authseries":"奥迪Q5","topicinfo":"Q5低配进化之路\u2014\u2014\u2014\u2014Q5升级多功能方向盘（附带编码故障清除！）奥迪Q5作为奥迪最为热门的suv，也是奥迪卖的比较火的"},{"topicid":56389084,"title":"2016年中国车市最大的笑话：本田冠道","lastreplydate":"2016-09-22 15:23:30","postusername":"douding888","replycounts":"191","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 20:29:17","memberid":25784148,"isvip":0,"headimg":"","nickname":"疯狂laoda","authseries":"","topicinfo":""},{"topicid":56384015,"title":"漯河第一台帝豪GL 属于我！属于我！（求版主射精）","lastreplydate":"2016-09-22 15:14:34","postusername":"arthursky","replycounts":"131","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:25:28","memberid":19111197,"isvip":0,"headimg":"","nickname":"vgsteyehn","authseries":"","topicinfo":""},{"topicid":56387424,"title":"难得土豪了一回，一甩手就把帝豪GL给订了！求精来！","lastreplydate":"2016-09-22 12:55:45","postusername":"楚国项王","replycounts":"123","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 19:30:28","memberid":31350401,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g6/M0C/51/0C/120X120_0_q87_autohomecar__wKgH3FfiaaWAHff-AAGOcu00tjM590.jpg","nickname":"会卖瓜的老汉与王婆","authseries":"","topicinfo":""},{"topicid":56385869,"title":"憋了好几天了，我也发几张照片吧，前段时间去4S看到的冠道。","lastreplydate":"2016-09-22 13:01:23","postusername":"不敢妄自尊大","replycounts":"52","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 18:27:29","memberid":30288444,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g13/M11/1C/27/120X120_0_q87_autohomecar__wKgH41fAqWWAPT70AAAOfiN-pEI506.jpg","nickname":"不敢妄自尊大","authseries":"","topicinfo":""},{"topicid":56385267,"title":"看了GL的配置，最终还是决定放弃卡罗拉","lastreplydate":"2016-09-22 15:11:53","postusername":"哈桑奇","replycounts":"73","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:04:07","memberid":31015737,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g7/M0E/52/72/120X120_0_q87_autohomecar__wKgH3VfiWqOAN4-zAAAgATCddHU702.jpg","nickname":"管良海","authseries":"","topicinfo":""},{"topicid":56384629,"title":"今天和强身出租车司机打架！","lastreplydate":"2016-09-22 15:20:37","postusername":"單彥曦她爹","replycounts":"132","ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:44:03","memberid":8114398,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2014/9/19/2f1af4fb-0a21-4697-9406-766f77d40aba_120X120.jpg","nickname":"tao68256156","authseries":"奔驰C级","topicinfo":"经过：今天老婆去红房子做个检查，做完12点了我看离城隍庙近，就想带着女儿去九曲桥那边看看鱼乌龟顺便吃个午饭。于是拦了辆出"},{"topicid":56388182,"title":"微信里看到的土豪汉兰达","lastreplydate":"2016-09-22 15:21:43","postusername":"畾之驕孨","replycounts":"42","ispictopic":1,"bbsid":771,"bbsname":"汉兰达论坛","postdate":"2016-09-21 19:57:03","memberid":9705063,"isvip":0,"headimg":"","nickname":"囘忆过去","authseries":"","topicinfo":""},{"topicid":56381389,"title":"销量能破5000我就服了","lastreplydate":"2016-09-22 15:20:25","postusername":"深圳小罗2008","replycounts":"129","ispictopic":0,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:13:36","memberid":9281291,"isvip":1,"headimg":"","nickname":"柏林1936","authseries":"金刚","topicinfo":""},{"topicid":56385282,"title":"\u201c过\u201d碰撞，\u201c斩\u201d盲测，帝豪GL涅槃新生的时候到了！","lastreplydate":"2016-09-22 11:14:49","postusername":"思服思想","replycounts":"107","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:04:44","memberid":31346391,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g22/M08/31/B3/120X120_0_q87_autohomecar__wKjBwVfiUkWAKW_vAAXil87qkvs639.jpg","nickname":"九月不哭","authseries":"","topicinfo":""},{"topicid":56384585,"title":"老婆生平的第一次驾驭【博越土豪金】绿博园一日游","lastreplydate":"2016-09-22 14:59:11","postusername":"卧云赏月01","replycounts":"175","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 17:42:32","memberid":8600595,"isvip":1,"headimg":"http://i2.autoimg.cn/usercenter//g14/M11/1D/D5/120X120_0_q87_autohomecar__wKjByVfDkEqAcpZTAAFXDLYVjHE373.jpg","nickname":"直升提速","authseries":"博越","topicinfo":"2016年四月份报的名，历时六个月，夫人终于拿到了身份证明的第二个证件，《机动车驾驶证》     说起这个也是一波三折，"},{"topicid":56382906,"title":"想二十出头买冠道!大家省省吧!有图为证!","lastreplydate":"2016-09-22 14:46:49","postusername":"万象前鈔","replycounts":"46","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 16:55:09","memberid":9950994,"isvip":1,"headimg":"","nickname":"轉角没逾到噯","authseries":"劲炫ASX","topicinfo":""},{"topicid":56393421,"title":"博越SUV通过性也敢糊弄","lastreplydate":"2016-09-22 15:07:52","postusername":"机械专业专注","replycounts":"165","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 22:43:26","memberid":21234728,"isvip":0,"headimg":"","nickname":"风云之弯道超车","authseries":"","topicinfo":"不多说了，内容改了，保留图片！莫名其妙的设计，是不是问题、重不重视由你。"},{"topicid":56395827,"title":"不知道老婆哪里听到的啪啪能减肥。","lastreplydate":"2016-09-22 15:21:36","postusername":"人中道同","replycounts":"96","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-22 00:24:09","memberid":8991992,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/12/23/e6311a98-06ba-44b0-ab3d-89f822409a02_120X120.jpg","nickname":"小撸怡情大撸伤心","authseries":"POLO","topicinfo":"疯了，到底谁说的。每天上完称之后，就逼我，日子苦啊。"},{"topicid":56388751,"title":"洒水车司机会不会被打死啊！","lastreplydate":"2016-09-22 15:23:27","postusername":"忠一心","replycounts":"75","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 20:17:57","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"作死啊，胆子太大了，还敢洒水！"},{"topicid":56382283,"title":"兵对兵，将对将，顶配对顶配","lastreplydate":"2016-09-22 15:14:53","postusername":"约束之地_2012","replycounts":"32","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:38:49","memberid":14780354,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g5/M07/4D/5D/120X120_0_q87_autohomecar__wKjB0lff6-OAdnfKAAAYPtsPo4s357.jpg","nickname":"dxkemy","authseries":"","topicinfo":""},{"topicid":56380352,"title":"对不住了，唐","lastreplydate":"2016-09-22 13:53:19","postusername":"宁奥渊2018","replycounts":"141","ispictopic":1,"bbsid":3430,"bbsname":"唐论坛","postdate":"2016-09-21 15:45:50","memberid":694202,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/11/27/dc9d8090-17e9-45ff-bfa7-2f33dc3f90ed_120X120.jpg","nickname":"post110","authseries":"奇瑞A3","topicinfo":""},{"topicid":56390627,"title":"撼路者声称要撼动全城去拼车，吹牛还是真事？","lastreplydate":"2016-09-22 10:50:35","postusername":"snowlzn","replycounts":"22","ispictopic":1,"bbsid":3518,"bbsname":"撼路者论坛","postdate":"2016-09-21 21:18:02","memberid":15489790,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g11/M0F/BE/7B/120X120_0_q87_autohomecar__wKgH0ld59FmAOIL2AAS5IEtiw2M092.jpg","nickname":"晨曦Tr","authseries":"","topicinfo":"平时就有拼车出行的习惯，一是可以分担点油钱，二也是为了践行环保理念，有时候在路上也能和拼车的朋友聊聊天儿，感觉挺好。一般"},{"topicid":56385356,"title":"前方十几辆无牌双闪新E","lastreplydate":"2016-09-22 15:21:12","postusername":"00000宅","replycounts":"15","ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-09-21 18:07:55","memberid":17229938,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g5/M07/A2/7A/120X120_0_q87_autohomecar__wKjB0ldcQ7aAF7vIAADJ_9m1RHY556.jpg","nickname":"我们走在大路上2015","authseries":"奔腾B70","topicinfo":""},{"topicid":56384006,"title":"途观车主眼中不一样的帝豪GL","lastreplydate":"2016-09-22 15:22:01","postusername":"沉沦欲海","replycounts":"225","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:25:08","memberid":21479965,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g7/M02/52/5F/120X120_0_q87_autohomecar__wKgH3VfiTOiAG1-YAAE2Qk9j5eU135.jpg","nickname":"爱琴海底的风","authseries":"","topicinfo":""},{"topicid":56385378,"title":"达成初步协议，给4S一天时间上报处理","lastreplydate":"2016-09-22 14:37:31","postusername":"晋江李荣钊","replycounts":"344","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 18:08:31","memberid":21526017,"isvip":1,"headimg":"","nickname":"红叶与白雪","authseries":"博越","topicinfo":"达成初步意见，给4s店一天时间反馈处理上报。见1楼9.21 早上出发去时里程情况2930公里，手机渣\u2026\u2026"},{"topicid":56380059,"title":"3.30订的自动智尚现在没有一点消息厂家能给个回话吗？？？","lastreplydate":"2016-09-22 12:40:47","postusername":"wszrj","replycounts":"49","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 15:37:31","memberid":6720781,"isvip":0,"headimg":"","nickname":"wszrj","authseries":"","topicinfo":"本人3月30在苍南吉易汽车4S店订购了一款博越1.8T自动智尚（黑色），订单上明确标明5月30号提车。在到时间前多次打电"},{"topicid":56384775,"title":"戏子骑摩托闯ETC失败，被栏杆砸死！","lastreplydate":"2016-09-22 15:11:27","postusername":"lituoy","replycounts":"140","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:48:18","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"这还要赖收费站不合适吧，明明是自己跟随汽车闯ETC自动杆，应该要赔偿栏杆损坏费用。摩托车不是这样骑的。"},{"topicid":56386400,"title":"三代瑞风S3、远景SUV对比帖","lastreplydate":"2016-09-22 15:03:24","postusername":"loveAMD","replycounts":"18","ispictopic":0,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-09-21 18:50:10","memberid":15412987,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g16/M11/D4/0A/120X120_0_q87_autohomecar__wKjBx1eMnMOAaLDuAAAiMhyBtR4195.jpg","nickname":"玢玢有李","authseries":"","topicinfo":""},{"topicid":56384908,"title":"雪佛兰科沃兹，热爱我的热爱，全方位多图分享。","lastreplydate":"2016-09-22 14:49:37","postusername":"钢铁男人的魅力","replycounts":"116","ispictopic":1,"bbsid":4105,"bbsname":"科沃兹论坛","postdate":"2016-09-21 17:52:49","memberid":21841492,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/12/23/72d07371-798b-40aa-887a-5d26b655d953_120X120.jpg","nickname":"Hura_","authseries":"科沃兹","topicinfo":"先说说购车经历吧，是之前打算买全新科鲁兹的，然后不喜欢，因为之前有看了思域，和领动，感觉全新科鲁兹上面有思域，下面有领动"},{"topicid":56379838,"title":"没图说个JB啊，上图来看看吧","lastreplydate":"2016-09-22 14:33:10","postusername":"风清云跑","replycounts":"58","ispictopic":1,"bbsid":4094,"bbsname":"传祺GS8论坛","postdate":"2016-09-21 15:31:14","memberid":694202,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/11/27/dc9d8090-17e9-45ff-bfa7-2f33dc3f90ed_120X120.jpg","nickname":"post110","authseries":"奇瑞A3","topicinfo":""},{"topicid":56384440,"title":"大家还认识这位美女吗？","lastreplydate":"2016-09-22 14:55:20","postusername":"拖拉机炮手","replycounts":"43","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:38:04","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"让你不看场合乱献唱"},{"topicid":56383409,"title":"真正的MPV都是轿车底盘！！比如轩朗！","lastreplydate":"2016-09-22 15:09:26","postusername":"惠娴雅絮","replycounts":"23","ispictopic":1,"bbsid":3987,"bbsname":"迈威论坛","postdate":"2016-09-21 17:07:37","memberid":23048185,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g7/M11/51/2A/120X120_0_q87_autohomecar__wKjB0FfiTPeAUslGAAAT1UmrohE800.jpg","nickname":"谁的笑声延续","authseries":"","topicinfo":""},{"topicid":56383272,"title":"9.58万的GL和10.69万的英朗-。-说真的，吉利还是有点太自信了","lastreplydate":"2016-09-22 15:13:08","postusername":"悦秀的","replycounts":"377","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:04:16","memberid":9458360,"isvip":0,"headimg":"http://i1.autoimg.cn/album/userheaders/2014/1/21/9dc12938-ff25-40ea-ba35-d2b533701c5d_120X120.jpg","nickname":"幻影之绝杀","authseries":"","topicinfo":""},{"topicid":56387284,"title":"宜昌首提吉利帝豪GL","lastreplydate":"2016-09-22 15:23:11","postusername":"viwei2016","replycounts":"126","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 19:25:48","memberid":31325123,"isvip":0,"headimg":"","nickname":"viwei2016","authseries":"","topicinfo":""},{"topicid":56385214,"title":"致那些一直在喊新A4L贵的人！！","lastreplydate":"2016-09-22 14:58:53","postusername":"装眼泪的罐子","replycounts":"159","ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-21 18:02:16","memberid":4939737,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/12/20/ca2fcea2-8c76-47a5-8565-299dcba9d61d_120X120.jpg","nickname":"装眼泪的罐子","authseries":"福克斯","topicinfo":""},{"topicid":56381209,"title":"2017款A4L风尚版已下订单，国庆节后提车，28W落地价还算满意","lastreplydate":"2016-09-22 15:08:48","postusername":"安庆王者杰zzz","replycounts":"63","ispictopic":0,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-21 16:08:06","memberid":16428810,"isvip":0,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/4/5/4bcfcc15-34b6-4903-8025-b1df6e9ee419_120X120.jpg","nickname":"未央不见_","authseries":"","topicinfo":""},{"topicid":56401455,"title":"第二季，萌妹当车模，海量美图~~~","lastreplydate":"2016-09-22 15:23:27","postusername":"狼牙月半湾","replycounts":"28","ispictopic":1,"bbsid":834,"bbsname":"君越论坛","postdate":"2016-09-22 10:04:07","memberid":29072763,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g12/M0B/0C/62/120X120_0_q87_autohomecar__wKgH4le4ADOAcv-5AAAhxP44Wk4676.jpg","nickname":"a285521395","authseries":"君越","topicinfo":"提车第二季~~~小弟的第一篇提车感谢各位看官跟斑竹大大的支持，上了汽车之家的首页。SO，这次为了答谢广大看官的支持，携带"},{"topicid":56383405,"title":"提个车都忘不了\u201c臭美\u201d的闺蜜","lastreplydate":"2016-09-22 14:56:16","postusername":"dearpopo","replycounts":"18","ispictopic":1,"bbsid":528,"bbsname":"帕萨特论坛","postdate":"2016-09-21 17:07:30","memberid":28308040,"isvip":1,"headimg":"http://i2.autoimg.cn/usercenter//g23/M0C/7F/DC/120X120_0_q87_autohomecar__wKgFV1dWkHiAW4oYAACxUGyMH3s901.jpg","nickname":"江南小筑001","authseries":"帕萨特","topicinfo":""},{"topicid":56380986,"title":"等待还是值得的，看到帝豪GL的定价，很良心，很亲民","lastreplydate":"2016-09-22 14:34:51","postusername":"欧阳先秀","replycounts":"91","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:02:10","memberid":30371116,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g5/M0A/1F/F8/120X120_0_q87_autohomecar__wKgH21fDkNWAcfd2AAByPdWobC0354.jpg","nickname":"zhuangwei1990","authseries":"","topicinfo":""},{"topicid":56394320,"title":"弯道跟新思域保持车距是明智的，分分钟上树报废给你看","lastreplydate":"2016-09-22 14:44:22","postusername":"dbjktr","replycounts":"60","ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-09-21 23:12:24","memberid":6455957,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2016/2/3/efb0d89f-3e91-4d26-94c8-36387fe2b7a4_120X120.jpg","nickname":"郁闷的星","authseries":"尚酷","topicinfo":"一个华丽的推头之后报废了，好在后车保持了车距避免了二次事故 直接上视频http://m.youku.com/video/"}]
     */

    private ResultBean result;
    /**
     * result : {"pagecount":4,"rowcount":29302,"pageindex":1,"list":[{"topicid":56382734,"title":"放毒，泄密，爆料，新款X80配置到底值不值那么多钱？","lastreplydate":"2016-09-22 15:14:29","postusername":"威志大汽车","replycounts":"24","ispictopic":1,"bbsid":3000,"bbsname":"奔腾X80论坛","postdate":"2016-09-21 16:50:40","memberid":3799692,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g14/M0B/F5/02/120X120_0_q87_autohomecar__wKgH5FepvXGAastnAAAY9jOXNTI817.jpg","nickname":"netoper","authseries":"","topicinfo":"废话不说，直接上图，看看新X80到底值不值那么多钱？别问我资料哪里来的，请叫我雷锋！比沃尔沃还安全，这句话确实\u201c好强硬\u201d"},{"topicid":56402302,"title":"【One night in 魔都】 Tomorrow Now/造就改变 感受科技与未来","lastreplydate":"2016-09-22 14:45:39","postusername":"inrain2","replycounts":"10","ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-22 10:27:53","memberid":3941632,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/8/dd92d8a7-1305-48b5-90b0-127b298d95ea_120X120.jpg","nickname":"inrain2","authseries":"奥迪A4L","topicinfo":""},{"topicid":56396892,"title":"博~史前文明~越~美丽灵州~之水洞沟游记(附后视镜风噪解决方案）","lastreplydate":"2016-09-22 14:18:23","postusername":"myxlove","replycounts":"221","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-22 02:36:15","memberid":30501943,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g20/M02/06/0A/120X120_0_q87_autohomecar__wKjBw1fJ2x-AVhNVAAW0ftOPZiE719.jpg","nickname":"myxlove","authseries":"博越","topicinfo":"水洞沟，一个史前文明的遗址，话不多说了，百度了一段简介，可以先阅读一下！后续高清大图奉上！水洞沟简介：  水洞沟古人类文"},{"topicid":56381305,"title":"我媳妇2次怀孕全掉了，今年7月又得了血液病","lastreplydate":"2016-09-22 15:18:04","postusername":"Levanas","replycounts":"162","ispictopic":0,"bbsid":117,"bbsname":"蒙迪欧论坛","postdate":"2016-09-21 16:11:03","memberid":10693059,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2014/9/5/064b5968-fde9-41d7-982c-c20a687baa17_120X120.jpg","nickname":"青岛大白","authseries":"蒙迪欧","topicinfo":""},{"topicid":56385500,"title":"仔细对比了奔腾B50和GL之后......","lastreplydate":"2016-09-22 15:15:26","postusername":"光看2013","replycounts":"153","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:13:41","memberid":19472650,"isvip":0,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/8/2/0b98b8a4-7cbe-41ce-abc7-445f1afcc431_120X120.jpg","nickname":"3599355abc","authseries":"","topicinfo":""},{"topicid":56388415,"title":"4s店 奔驰e200 迈巴赫套间 太霸气","lastreplydate":"2016-09-22 15:08:34","postusername":"37度的大男生","replycounts":"26","ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-09-21 20:05:31","memberid":31206289,"isvip":0,"headimg":"","nickname":"黑夜来临之时","authseries":"","topicinfo":""},{"topicid":56381556,"title":"从完全忽略到爱不释手！","lastreplydate":"2016-09-22 14:37:10","postusername":"夏日疯","replycounts":"55","ispictopic":1,"bbsid":153,"bbsname":"宝马7系论坛","postdate":"2016-09-21 16:18:45","memberid":4076984,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2013/1/2/13410165-721d-4cb0-9ab8-4bd33de1f3c0_120X120.jpg","nickname":"陈修宇","authseries":"君越","topicinfo":"其实换车的想法在14年年中就有了， 因为当时的肥越A柱确实太挡视线了（本人平时开车有点虎，但是肥越确实是部好车）。但是由"},{"topicid":56382890,"title":"大家给处女座一个建议，我洗耳恭听！","lastreplydate":"2016-09-22 14:43:19","postusername":"a遥不可及a","replycounts":"150","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:54:47","memberid":14935546,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g16/M07/51/B1/120X120_0_q87_autohomecar__wKgH5lfiSiiAXPuxAADeR-FI33g962.jpg","nickname":"贵族浪漫","authseries":"","topicinfo":""},{"topicid":56391760,"title":"媳妇不让碰，离不离？","lastreplydate":"2016-09-22 15:15:18","postusername":"pjx88","replycounts":"198","ispictopic":0,"bbsid":100002,"bbsname":"北京论坛","postdate":"2016-09-21 21:51:42","memberid":21524637,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g9/M0C/14/9D/120X120_0_q87_autohomecar__wKgH0Fe-eEiAFgt5AACsYSiQLcU110.jpg","nickname":"01v96","authseries":"","topicinfo":"媳妇不让碰，婚前就是性冷淡，我怎么办？孩子刚一岁多。二十多岁就这样，以后的日子怎么熬啊。要孩子时候就死人似的躺那，催我尽"},{"topicid":56379974,"title":"劳资开始搞安定，是我兄弟的别插手，不是我兄弟的就当看戏","lastreplydate":"2016-09-22 15:14:43","postusername":"niceking","replycounts":"201","ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 15:34:46","memberid":31336175,"isvip":0,"headimg":"","nickname":"俊行天下2016","authseries":"","topicinfo":"玩嘛，谁怕谁，第一步，明天早上十点，徐家汇汽家见，全程直播，连续剧么，大家连续下去"},{"topicid":56385984,"title":"松江街头惊现防空导弹","lastreplydate":"2016-09-22 15:11:18","postusername":"帅的抠脚","replycounts":"98","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 18:32:17","memberid":2693668,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2014/9/6/dcf30fc0-b3e5-4f44-8fe0-e0ff900503c2_120X120.jpg","nickname":"上海顶端","authseries":"宝来/宝来经典","topicinfo":"貌似往金山方向的这个路口平时警察不来"},{"topicid":56383832,"title":"女司机停车挡住生命车道  诅咒患者早点死","lastreplydate":"2016-09-22 15:06:55","postusername":"hl1997","replycounts":"69","ispictopic":1,"bbsid":46,"bbsname":"普拉多论坛","postdate":"2016-09-21 17:19:50","memberid":8933521,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g20/M15/18/76/120X120_0_q87_autohomecar__wKgFWVfVJ9yAI5HJAAFDvMS9-fc698.jpg","nickname":"举头三尺有神明1","authseries":"","topicinfo":""},{"topicid":56391531,"title":"新蓝鸟夜间偶遇新思域，就停在边上一起同框合影一下~","lastreplydate":"2016-09-22 13:59:11","postusername":"shmily晴天","replycounts":"50","ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-09-21 21:45:01","memberid":17574693,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g23/M08/99/4D/120X120_0_q87_autohomecar__wKgFXFbUgX6AabLFAABBKWd4YpQ466.jpg","nickname":"蜗牛壳吧","authseries":"LANNIA 蓝鸟","topicinfo":"新蓝鸟，新思域，昂克赛拉，都是我喜欢的车型，年轻、动感、时尚！"},{"topicid":56384331,"title":"Q5低配进化之路\u2014升级多功能方向盘最全教程（附编码故障清除）","lastreplydate":"2016-09-22 13:03:46","postusername":"潇洒老白","replycounts":"46","ispictopic":1,"bbsid":812,"bbsname":"奥迪Q5论坛","postdate":"2016-09-21 17:34:15","memberid":4604210,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2013/1/30/83e8fa07-3105-445b-9ed4-4423d5d40b9d_120X120.jpg","nickname":"潇洒老白","authseries":"奥迪Q5","topicinfo":"Q5低配进化之路\u2014\u2014\u2014\u2014Q5升级多功能方向盘（附带编码故障清除！）奥迪Q5作为奥迪最为热门的suv，也是奥迪卖的比较火的"},{"topicid":56389084,"title":"2016年中国车市最大的笑话：本田冠道","lastreplydate":"2016-09-22 15:23:30","postusername":"douding888","replycounts":"191","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 20:29:17","memberid":25784148,"isvip":0,"headimg":"","nickname":"疯狂laoda","authseries":"","topicinfo":""},{"topicid":56384015,"title":"漯河第一台帝豪GL 属于我！属于我！（求版主射精）","lastreplydate":"2016-09-22 15:14:34","postusername":"arthursky","replycounts":"131","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:25:28","memberid":19111197,"isvip":0,"headimg":"","nickname":"vgsteyehn","authseries":"","topicinfo":""},{"topicid":56387424,"title":"难得土豪了一回，一甩手就把帝豪GL给订了！求精来！","lastreplydate":"2016-09-22 12:55:45","postusername":"楚国项王","replycounts":"123","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 19:30:28","memberid":31350401,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g6/M0C/51/0C/120X120_0_q87_autohomecar__wKgH3FfiaaWAHff-AAGOcu00tjM590.jpg","nickname":"会卖瓜的老汉与王婆","authseries":"","topicinfo":""},{"topicid":56385869,"title":"憋了好几天了，我也发几张照片吧，前段时间去4S看到的冠道。","lastreplydate":"2016-09-22 13:01:23","postusername":"不敢妄自尊大","replycounts":"52","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 18:27:29","memberid":30288444,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g13/M11/1C/27/120X120_0_q87_autohomecar__wKgH41fAqWWAPT70AAAOfiN-pEI506.jpg","nickname":"不敢妄自尊大","authseries":"","topicinfo":""},{"topicid":56385267,"title":"看了GL的配置，最终还是决定放弃卡罗拉","lastreplydate":"2016-09-22 15:11:53","postusername":"哈桑奇","replycounts":"73","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:04:07","memberid":31015737,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g7/M0E/52/72/120X120_0_q87_autohomecar__wKgH3VfiWqOAN4-zAAAgATCddHU702.jpg","nickname":"管良海","authseries":"","topicinfo":""},{"topicid":56384629,"title":"今天和强身出租车司机打架！","lastreplydate":"2016-09-22 15:20:37","postusername":"單彥曦她爹","replycounts":"132","ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:44:03","memberid":8114398,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2014/9/19/2f1af4fb-0a21-4697-9406-766f77d40aba_120X120.jpg","nickname":"tao68256156","authseries":"奔驰C级","topicinfo":"经过：今天老婆去红房子做个检查，做完12点了我看离城隍庙近，就想带着女儿去九曲桥那边看看鱼乌龟顺便吃个午饭。于是拦了辆出"},{"topicid":56388182,"title":"微信里看到的土豪汉兰达","lastreplydate":"2016-09-22 15:21:43","postusername":"畾之驕孨","replycounts":"42","ispictopic":1,"bbsid":771,"bbsname":"汉兰达论坛","postdate":"2016-09-21 19:57:03","memberid":9705063,"isvip":0,"headimg":"","nickname":"囘忆过去","authseries":"","topicinfo":""},{"topicid":56381389,"title":"销量能破5000我就服了","lastreplydate":"2016-09-22 15:20:25","postusername":"深圳小罗2008","replycounts":"129","ispictopic":0,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:13:36","memberid":9281291,"isvip":1,"headimg":"","nickname":"柏林1936","authseries":"金刚","topicinfo":""},{"topicid":56385282,"title":"\u201c过\u201d碰撞，\u201c斩\u201d盲测，帝豪GL涅槃新生的时候到了！","lastreplydate":"2016-09-22 11:14:49","postusername":"思服思想","replycounts":"107","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 18:04:44","memberid":31346391,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g22/M08/31/B3/120X120_0_q87_autohomecar__wKjBwVfiUkWAKW_vAAXil87qkvs639.jpg","nickname":"九月不哭","authseries":"","topicinfo":""},{"topicid":56384585,"title":"老婆生平的第一次驾驭【博越土豪金】绿博园一日游","lastreplydate":"2016-09-22 14:59:11","postusername":"卧云赏月01","replycounts":"175","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 17:42:32","memberid":8600595,"isvip":1,"headimg":"http://i2.autoimg.cn/usercenter//g14/M11/1D/D5/120X120_0_q87_autohomecar__wKjByVfDkEqAcpZTAAFXDLYVjHE373.jpg","nickname":"直升提速","authseries":"博越","topicinfo":"2016年四月份报的名，历时六个月，夫人终于拿到了身份证明的第二个证件，《机动车驾驶证》     说起这个也是一波三折，"},{"topicid":56382906,"title":"想二十出头买冠道!大家省省吧!有图为证!","lastreplydate":"2016-09-22 14:46:49","postusername":"万象前鈔","replycounts":"46","ispictopic":1,"bbsid":4102,"bbsname":"冠道论坛","postdate":"2016-09-21 16:55:09","memberid":9950994,"isvip":1,"headimg":"","nickname":"轉角没逾到噯","authseries":"劲炫ASX","topicinfo":""},{"topicid":56393421,"title":"博越SUV通过性也敢糊弄","lastreplydate":"2016-09-22 15:07:52","postusername":"机械专业专注","replycounts":"165","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 22:43:26","memberid":21234728,"isvip":0,"headimg":"","nickname":"风云之弯道超车","authseries":"","topicinfo":"不多说了，内容改了，保留图片！莫名其妙的设计，是不是问题、重不重视由你。"},{"topicid":56395827,"title":"不知道老婆哪里听到的啪啪能减肥。","lastreplydate":"2016-09-22 15:21:36","postusername":"人中道同","replycounts":"96","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-22 00:24:09","memberid":8991992,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/12/23/e6311a98-06ba-44b0-ab3d-89f822409a02_120X120.jpg","nickname":"小撸怡情大撸伤心","authseries":"POLO","topicinfo":"疯了，到底谁说的。每天上完称之后，就逼我，日子苦啊。"},{"topicid":56388751,"title":"洒水车司机会不会被打死啊！","lastreplydate":"2016-09-22 15:23:27","postusername":"忠一心","replycounts":"75","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 20:17:57","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"作死啊，胆子太大了，还敢洒水！"},{"topicid":56382283,"title":"兵对兵，将对将，顶配对顶配","lastreplydate":"2016-09-22 15:14:53","postusername":"约束之地_2012","replycounts":"32","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:38:49","memberid":14780354,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g5/M07/4D/5D/120X120_0_q87_autohomecar__wKjB0lff6-OAdnfKAAAYPtsPo4s357.jpg","nickname":"dxkemy","authseries":"","topicinfo":""},{"topicid":56380352,"title":"对不住了，唐","lastreplydate":"2016-09-22 13:53:19","postusername":"宁奥渊2018","replycounts":"141","ispictopic":1,"bbsid":3430,"bbsname":"唐论坛","postdate":"2016-09-21 15:45:50","memberid":694202,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/11/27/dc9d8090-17e9-45ff-bfa7-2f33dc3f90ed_120X120.jpg","nickname":"post110","authseries":"奇瑞A3","topicinfo":""},{"topicid":56390627,"title":"撼路者声称要撼动全城去拼车，吹牛还是真事？","lastreplydate":"2016-09-22 10:50:35","postusername":"snowlzn","replycounts":"22","ispictopic":1,"bbsid":3518,"bbsname":"撼路者论坛","postdate":"2016-09-21 21:18:02","memberid":15489790,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g11/M0F/BE/7B/120X120_0_q87_autohomecar__wKgH0ld59FmAOIL2AAS5IEtiw2M092.jpg","nickname":"晨曦Tr","authseries":"","topicinfo":"平时就有拼车出行的习惯，一是可以分担点油钱，二也是为了践行环保理念，有时候在路上也能和拼车的朋友聊聊天儿，感觉挺好。一般"},{"topicid":56385356,"title":"前方十几辆无牌双闪新E","lastreplydate":"2016-09-22 15:21:12","postusername":"00000宅","replycounts":"15","ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-09-21 18:07:55","memberid":17229938,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g5/M07/A2/7A/120X120_0_q87_autohomecar__wKjB0ldcQ7aAF7vIAADJ_9m1RHY556.jpg","nickname":"我们走在大路上2015","authseries":"奔腾B70","topicinfo":""},{"topicid":56384006,"title":"途观车主眼中不一样的帝豪GL","lastreplydate":"2016-09-22 15:22:01","postusername":"沉沦欲海","replycounts":"225","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:25:08","memberid":21479965,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g7/M02/52/5F/120X120_0_q87_autohomecar__wKgH3VfiTOiAG1-YAAE2Qk9j5eU135.jpg","nickname":"爱琴海底的风","authseries":"","topicinfo":""},{"topicid":56385378,"title":"达成初步协议，给4S一天时间上报处理","lastreplydate":"2016-09-22 14:37:31","postusername":"晋江李荣钊","replycounts":"344","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 18:08:31","memberid":21526017,"isvip":1,"headimg":"","nickname":"红叶与白雪","authseries":"博越","topicinfo":"达成初步意见，给4s店一天时间反馈处理上报。见1楼9.21 早上出发去时里程情况2930公里，手机渣\u2026\u2026"},{"topicid":56380059,"title":"3.30订的自动智尚现在没有一点消息厂家能给个回话吗？？？","lastreplydate":"2016-09-22 12:40:47","postusername":"wszrj","replycounts":"49","ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-09-21 15:37:31","memberid":6720781,"isvip":0,"headimg":"","nickname":"wszrj","authseries":"","topicinfo":"本人3月30在苍南吉易汽车4S店订购了一款博越1.8T自动智尚（黑色），订单上明确标明5月30号提车。在到时间前多次打电"},{"topicid":56384775,"title":"戏子骑摩托闯ETC失败，被栏杆砸死！","lastreplydate":"2016-09-22 15:11:27","postusername":"lituoy","replycounts":"140","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:48:18","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"这还要赖收费站不合适吧，明明是自己跟随汽车闯ETC自动杆，应该要赔偿栏杆损坏费用。摩托车不是这样骑的。"},{"topicid":56386400,"title":"三代瑞风S3、远景SUV对比帖","lastreplydate":"2016-09-22 15:03:24","postusername":"loveAMD","replycounts":"18","ispictopic":0,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-09-21 18:50:10","memberid":15412987,"isvip":0,"headimg":"http://i3.autoimg.cn/usercenter//g16/M11/D4/0A/120X120_0_q87_autohomecar__wKjBx1eMnMOAaLDuAAAiMhyBtR4195.jpg","nickname":"玢玢有李","authseries":"","topicinfo":""},{"topicid":56384908,"title":"雪佛兰科沃兹，热爱我的热爱，全方位多图分享。","lastreplydate":"2016-09-22 14:49:37","postusername":"钢铁男人的魅力","replycounts":"116","ispictopic":1,"bbsid":4105,"bbsname":"科沃兹论坛","postdate":"2016-09-21 17:52:49","memberid":21841492,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/12/23/72d07371-798b-40aa-887a-5d26b655d953_120X120.jpg","nickname":"Hura_","authseries":"科沃兹","topicinfo":"先说说购车经历吧，是之前打算买全新科鲁兹的，然后不喜欢，因为之前有看了思域，和领动，感觉全新科鲁兹上面有思域，下面有领动"},{"topicid":56379838,"title":"没图说个JB啊，上图来看看吧","lastreplydate":"2016-09-22 14:33:10","postusername":"风清云跑","replycounts":"58","ispictopic":1,"bbsid":4094,"bbsname":"传祺GS8论坛","postdate":"2016-09-21 15:31:14","memberid":694202,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/11/27/dc9d8090-17e9-45ff-bfa7-2f33dc3f90ed_120X120.jpg","nickname":"post110","authseries":"奇瑞A3","topicinfo":""},{"topicid":56384440,"title":"大家还认识这位美女吗？","lastreplydate":"2016-09-22 14:55:20","postusername":"拖拉机炮手","replycounts":"43","ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-09-21 17:38:04","memberid":12986987,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/1/9/d7bbc250-50d5-49d4-b865-d5dd7fbe7568_120X120.jpg","nickname":"Normandy77","authseries":"荣威550","topicinfo":"让你不看场合乱献唱"},{"topicid":56383409,"title":"真正的MPV都是轿车底盘！！比如轩朗！","lastreplydate":"2016-09-22 15:09:26","postusername":"惠娴雅絮","replycounts":"23","ispictopic":1,"bbsid":3987,"bbsname":"迈威论坛","postdate":"2016-09-21 17:07:37","memberid":23048185,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g7/M11/51/2A/120X120_0_q87_autohomecar__wKjB0FfiTPeAUslGAAAT1UmrohE800.jpg","nickname":"谁的笑声延续","authseries":"","topicinfo":""},{"topicid":56383272,"title":"9.58万的GL和10.69万的英朗-。-说真的，吉利还是有点太自信了","lastreplydate":"2016-09-22 15:13:08","postusername":"悦秀的","replycounts":"377","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 17:04:16","memberid":9458360,"isvip":0,"headimg":"http://i1.autoimg.cn/album/userheaders/2014/1/21/9dc12938-ff25-40ea-ba35-d2b533701c5d_120X120.jpg","nickname":"幻影之绝杀","authseries":"","topicinfo":""},{"topicid":56387284,"title":"宜昌首提吉利帝豪GL","lastreplydate":"2016-09-22 15:23:11","postusername":"viwei2016","replycounts":"126","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 19:25:48","memberid":31325123,"isvip":0,"headimg":"","nickname":"viwei2016","authseries":"","topicinfo":""},{"topicid":56385214,"title":"致那些一直在喊新A4L贵的人！！","lastreplydate":"2016-09-22 14:58:53","postusername":"装眼泪的罐子","replycounts":"159","ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-21 18:02:16","memberid":4939737,"isvip":1,"headimg":"http://i0.autoimg.cn/album/userheaders/2012/12/20/ca2fcea2-8c76-47a5-8565-299dcba9d61d_120X120.jpg","nickname":"装眼泪的罐子","authseries":"福克斯","topicinfo":""},{"topicid":56381209,"title":"2017款A4L风尚版已下订单，国庆节后提车，28W落地价还算满意","lastreplydate":"2016-09-22 15:08:48","postusername":"安庆王者杰zzz","replycounts":"63","ispictopic":0,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-09-21 16:08:06","memberid":16428810,"isvip":0,"headimg":"http://i0.autoimg.cn/album/userheaders/2015/4/5/4bcfcc15-34b6-4903-8025-b1df6e9ee419_120X120.jpg","nickname":"未央不见_","authseries":"","topicinfo":""},{"topicid":56401455,"title":"第二季，萌妹当车模，海量美图~~~","lastreplydate":"2016-09-22 15:23:27","postusername":"狼牙月半湾","replycounts":"28","ispictopic":1,"bbsid":834,"bbsname":"君越论坛","postdate":"2016-09-22 10:04:07","memberid":29072763,"isvip":1,"headimg":"http://i3.autoimg.cn/usercenter//g12/M0B/0C/62/120X120_0_q87_autohomecar__wKgH4le4ADOAcv-5AAAhxP44Wk4676.jpg","nickname":"a285521395","authseries":"君越","topicinfo":"提车第二季~~~小弟的第一篇提车感谢各位看官跟斑竹大大的支持，上了汽车之家的首页。SO，这次为了答谢广大看官的支持，携带"},{"topicid":56383405,"title":"提个车都忘不了\u201c臭美\u201d的闺蜜","lastreplydate":"2016-09-22 14:56:16","postusername":"dearpopo","replycounts":"18","ispictopic":1,"bbsid":528,"bbsname":"帕萨特论坛","postdate":"2016-09-21 17:07:30","memberid":28308040,"isvip":1,"headimg":"http://i2.autoimg.cn/usercenter//g23/M0C/7F/DC/120X120_0_q87_autohomecar__wKgFV1dWkHiAW4oYAACxUGyMH3s901.jpg","nickname":"江南小筑001","authseries":"帕萨特","topicinfo":""},{"topicid":56380986,"title":"等待还是值得的，看到帝豪GL的定价，很良心，很亲民","lastreplydate":"2016-09-22 14:34:51","postusername":"欧阳先秀","replycounts":"91","ispictopic":1,"bbsid":4139,"bbsname":"帝豪GL论坛","postdate":"2016-09-21 16:02:10","memberid":30371116,"isvip":0,"headimg":"http://i2.autoimg.cn/usercenter//g5/M0A/1F/F8/120X120_0_q87_autohomecar__wKgH21fDkNWAcfd2AAByPdWobC0354.jpg","nickname":"zhuangwei1990","authseries":"","topicinfo":""},{"topicid":56394320,"title":"弯道跟新思域保持车距是明智的，分分钟上树报废给你看","lastreplydate":"2016-09-22 14:44:22","postusername":"dbjktr","replycounts":"60","ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-09-21 23:12:24","memberid":6455957,"isvip":1,"headimg":"http://i1.autoimg.cn/album/userheaders/2016/2/3/efb0d89f-3e91-4d26-94c8-36387fe2b7a4_120X120.jpg","nickname":"郁闷的星","authseries":"尚酷","topicinfo":"一个华丽的推头之后报废了，好在后车保持了车距避免了二次事故 直接上视频http://m.youku.com/video/"}]}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int pagecount;
        private int rowcount;
        private int pageindex;
        /**
         * topicid : 56382734
         * title : 放毒，泄密，爆料，新款X80配置到底值不值那么多钱？
         * lastreplydate : 2016-09-22 15:14:29
         * postusername : 威志大汽车
         * replycounts : 24
         * ispictopic : 1
         * bbsid : 3000
         * bbsname : 奔腾X80论坛
         * postdate : 2016-09-21 16:50:40
         * memberid : 3799692
         * isvip : 0
         * headimg : http://i2.autoimg.cn/usercenter//g14/M0B/F5/02/120X120_0_q87_autohomecar__wKgH5FepvXGAastnAAAY9jOXNTI817.jpg
         * nickname : netoper
         * authseries :
         * topicinfo : 废话不说，直接上图，看看新X80到底值不值那么多钱？别问我资料哪里来的，请叫我雷锋！比沃尔沃还安全，这句话确实“好强硬”
         */

        private List<ListBean> list;

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private String replycounts;
            private int ispictopic;
            private int bbsid;
            private String bbsname;
            private String postdate;
            private int memberid;
            private int isvip;
            private String headimg;
            private String nickname;
            private String authseries;
            private String topicinfo;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public String getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(String replycounts) {
                this.replycounts = replycounts;
            }

            public int getIspictopic() {
                return ispictopic;
            }

            public void setIspictopic(int ispictopic) {
                this.ispictopic = ispictopic;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }

            public String getPostdate() {
                return postdate;
            }

            public void setPostdate(String postdate) {
                this.postdate = postdate;
            }

            public int getMemberid() {
                return memberid;
            }

            public void setMemberid(int memberid) {
                this.memberid = memberid;
            }

            public int getIsvip() {
                return isvip;
            }

            public void setIsvip(int isvip) {
                this.isvip = isvip;
            }

            public String getHeadimg() {
                return headimg;
            }

            public void setHeadimg(String headimg) {
                this.headimg = headimg;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getAuthseries() {
                return authseries;
            }

            public void setAuthseries(String authseries) {
                this.authseries = authseries;
            }

            public String getTopicinfo() {
                return topicinfo;
            }

            public void setTopicinfo(String topicinfo) {
                this.topicinfo = topicinfo;
            }
        }
    }
}
