package com.example.dllo.recommend.recommends;

import java.util.List;

/**
 * Created by dllo on 16/10/8.
 */
public class RecommendsBean {

    /**
     * rowcount : 10630
     * isloadmore : true
     * headlineinfo : {"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/160x120_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":155,"pagecount":0,"jumppage":1,"lasttime":"","updatetime":"20161008094801"}
     * focusimg : [{"updatetime":"20161007205146","id":91387,"imgurl":"http://www3.autoimg.cn/newsdfs/g14/M0C/65/1D/640x320_0_autohomecar__wKgH1Vf3mbWAQnyYAAiaxcqML6U359.jpg","title":"坐大飞艇vs劫持无人机 汽车之家欧洲挑战之旅","type":"原创","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":2,"fromtype":0},{"updatetime":"20161008070810","id":893702,"imgurl":"http://www2.autoimg.cn/newsdfs/g9/M01/5A/DC/640x320_0_autohomecar__wKgH0FfqMa6AWUVhAAiqPhomYBw135.jpg","title":"来得早不如来得巧 试驾丰田卡罗拉1.2T","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0},{"updatetime":"20161008070758","id":893484,"imgurl":"http://www3.autoimg.cn/newsdfs/g14/M0C/6A/A8/640x320_0_autohomecar__wKgH5Ff4NUyAXC85AAnrbDuofvY488.jpg","title":"越长越年轻 试北京现代悦纳1.4L 6AT","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0},{"updatetime":"20160928160424","id":55868682,"imgurl":"http://www2.autoimg.cn/newsdfs/g22/M08/3D/5A/640x320_0_autohomecar__wKjBwVfreYiAY0p4AAJGM3LUd8Y191.jpg","title":"空间大有安全感 分享博越提车感受","type":"","replycount":0,"pageindex":3788,"JumpType":0,"jumpurl":"","mediatype":4,"fromtype":0},{"updatetime":"20160929180407","id":55247505,"imgurl":"http://www2.autoimg.cn/newsdfs/g6/M14/5E/E1/640x320_0_autohomecar__wKgH3Ffs5xeAJr4CAAHeiUdliXQ370.jpg","title":"喜欢多年终圆夙愿 捷达1.6L购车记","type":"","replycount":0,"pageindex":16,"JumpType":0,"jumpurl":"","mediatype":4,"fromtype":0},{"updatetime":"20161008071054","id":893157,"imgurl":"http://www3.autoimg.cn/newsdfs/g11/M11/65/65/640x320_0_autohomecar__wKgH0lf3AR6Aa0BBAARm7aDjbIw122.jpg","title":"不一样的美好 穿越318国道川藏游记","type":"汽车文化","replycount":0,"pageindex":15,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0}]
     * newslist : [{"id":539251,"title":"消费升级、更迭，小型车已成明日黄花？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M03/4A/8C/160x120_0_autohomecar__wKjBxFf4S2SAc6mNAARM6Dr4wzM592.jpg","replycount":1,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008092702"},{"id":893976,"title":"采用新品牌销售 曝更多大众电动车计划","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0D/6B/4B/160x120_0_autohomecar__wKgH41f4VZKATcE7AAE3892GX4M267.jpg","replycount":19,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008101154"},{"id":91328,"title":"内饰太骚气 定制版奥迪RS 7全面展示","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M0C/5C/28/240x180_0_autohomecar__wKgHy1ft_XiAOaDQAAETdf7vgqw835.jpg","replycount":27308,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930135153"},{"id":539273,"title":"差价6000元 帝豪GL离卡罗拉有多远？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M08/46/A3/160x120_0_autohomecar__wKgFVVf4U4-AOOP5AAFYUhVwruU332.jpg","replycount":176,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008100153"},{"id":893975,"title":"共9款车型 众泰SR9将于10月12日下线","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M15/4A/E1/160x120_0_autohomecar__wKjBwVf4SdiAHaM8AAEy_L0cQ70698.jpg","replycount":286,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008095709"},{"id":893974,"title":"或基于大众Amarok 斯柯达皮卡消息曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M07/4B/32/160x120_0_autohomecar__wKgFWFf4T-GAfVlkAAEMADiwQq0981.jpg","replycount":24,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094619"},{"id":539257,"title":"13-17万中端SUV在等待和呼唤自己的项羽","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/24/160x120_0_autohomecar__wKgFWFf4SDGAC4puAAPb7rOig4Q673.jpg","replycount":43,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008091322"},{"id":91366,"title":"运动版途观 外媒试驾西雅特Ateca 1.4T","mediatype":3,"type":"试车","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M11/60/57/240x180_0_autohomecar__wKjB01fuHtCAdQxTAAFS7NqIa8E756.jpg","replycount":13479,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930161415"},{"id":539236,"title":"修完就卖？卖家为何如此迫不及待！","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M03/69/D1/160x120_0_autohomecar__wKgH4Ff3IrKAVayrADBDLJIvHRA517.JPG","replycount":84,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007161915"},{"id":531667,"title":"【黑知识讲堂】有了Turbo还要VTEC吗？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M06/69/0A/160x120_0_autohomecar__wKjB0Vf3stKAA_2VAAFLKhvkETQ485.jpg","replycount":148,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007223604"},{"id":91345,"title":"实在太任性了 实拍警车场地疯狂漂移","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0D/60/CD/240x180_0_autohomecar__wKgH5lfuBtqATKEkAAEooqv40PY904.jpg","replycount":13740,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143156"},{"id":539206,"title":"韩系动向，看韩系车前三季度销量如何","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/65/43/160x120_0_autohomecar__wKgH1Ff3B8mAM8EMAANn1SivonM997.jpg","replycount":386,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007162706"},{"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/160x120_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":155,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094801"},{"id":91351,"title":"霸气大尾翼 街拍橘色保时捷918 Spyder","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M0D/5D/71/240x180_0_autohomecar__wKgHzFfuBwKAQ8RKAAGC5y0SY-A038.jpg","replycount":18554,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143235"},{"id":54453553,"title":"选车是乐趣更是学习 提瑞风S2 1.5L","mediatype":5,"type":"a","time":"2016-10-08","indexdetail":"贵州论坛","smallpic":"http://club2.autoimg.cn/album/g14/M06/D7/AD/userphotos/2016/07/21/00/240180_wKgH5FePpHKANpFkAAEum0ZmjJY961.jpg","replycount":139,"pagecount":0,"jumppage":100008,"lasttime":"","newstype":0,"updatetime":"20161008070000"},{"id":538717,"title":"汽车江湖十五回:路虎发现5是神行Plus吗","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M05/46/41/160x120_0_autohomecar__wKgFV1f3BLqAQzrNAACAr0o74kc286.jpg","replycount":175,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007101317"},{"id":893967,"title":"Mustang Shelby GT350或配双离合变速箱","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M06/46/E7/160x120_0_autohomecar__wKgFVFf3QzyAM_qLAAEqLY302OQ982.jpg","replycount":123,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007152709"},{"id":893966,"title":"或达609马力 宝马M8新信息及假想图曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0C/65/C3/160x120_0_autohomecar__wKgH0lf3OIqAesV1AADTyETBot4234.jpg","replycount":175,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007215041"},{"id":893971,"title":"2017年推出 新一代欧宝Corsa谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M08/6D/53/160x120_0_autohomecar__wKgH3lf3mv-ARUWpAAGEU1zmcj0091.jpg","replycount":27,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007205430"},{"id":91348,"title":"路怒害人害己 两辆车逆行狂飙斗气互别","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/5C/EB/240x180_0_autohomecar__wKgH11fuBu-AJNhaAADml6wGFco256.jpg","replycount":61748,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143216"},{"id":893968,"title":"11月试营 雷诺自动驾驶示范区落户武汉","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M07/6A/39/160x120_0_autohomecar__wKgH4Ff3YxqACJe-AAFqAImLz-o039.jpg","replycount":29,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008090247"},{"id":893973,"title":"周末改装车集锦第342期 日产改装车汇总","mediatype":1,"type":"改装/赛事","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M0B/65/6F/160x120_0_autohomecar__wKgH1Vf31o6AQtEpAAGIxU_I1Ho241.jpg","replycount":25,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094016"},{"id":537732,"title":"三缸时代来临？盘点未来您的三缸座驾！","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g7/M09/69/A3/160x120_0_autohomecar__wKjB0Ff3Y3uAEqokAAFDUffHGus132.jpg","replycount":224,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007165740"},{"id":893960,"title":"形散神不散 避免审美疲劳的家族化设计","mediatype":1,"type":"技术设计","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/65/FD/160x120_0_autohomecar__wKgH11f3jUiAP_wtAAF9PJXVwUA953.jpg","replycount":102,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008100536"},{"id":532134,"title":"为何A6L/5系卖30多万 奔驰E级还是能赢","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M01/0D/F7/160x120_0_autohomecar__wKgH0Ve7lGGAZfLqAATGCLlRNuQ028.jpg","replycount":921,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007224045"},{"id":893702,"title":"来得早不如来得巧 试驾丰田卡罗拉1.2T","mediatype":1,"type":"试驾评测","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M13/5A/ED/160x120_0_autohomecar__wKgH3FfqMaqAXnqeAAHXSCPdemI465.jpg","replycount":576,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008095635"},{"id":893484,"title":"越长越年轻 试北京现代悦纳1.4L 6AT","mediatype":1,"type":"试驾评测","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M13/52/F5/160x120_0_autohomecar__wKgH4FfjSwiADOjpAAFHT8S_sn4272.jpg","replycount":365,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008081333"},{"id":91346,"title":"玩得真尽兴 C 63 AMG/M5 E60场地漂移","mediatype":3,"type":"花边","time":"2016-10-07","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M06/5C/3B/240x180_0_autohomecar__wKgHy1fuBuKAXl8uAAEyWpgx-8c939.jpg","replycount":27283,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143203"},{"id":539229,"title":"阿鲁的觉醒，铃木大R迎来重大换代！","mediatype":2,"type":"","time":"2016-10-07","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M04/68/77/160x120_0_autohomecar__wKgHz1f3EGWAa-mmAALQwlNIM88335.jpg","replycount":207,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007222848"},{"id":91342,"title":"很是过瘾 BAJA赛车征服各种糟糕路况","mediatype":3,"type":"花边","time":"2016-10-07","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M12/60/58/240x180_0_autohomecar__wKgH4VfuAJaAGGssAAEMd2igIoI942.jpg","replycount":23267,"pagecount":0,"jumppage":1,"lasttime":"201610072200574423272","newstype":0,"updatetime":"20160930140511"}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":10630,"isloadmore":true,"headlineinfo":{"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/160x120_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":155,"pagecount":0,"jumppage":1,"lasttime":"","updatetime":"20161008094801"},"focusimg":[{"updatetime":"20161007205146","id":91387,"imgurl":"http://www3.autoimg.cn/newsdfs/g14/M0C/65/1D/640x320_0_autohomecar__wKgH1Vf3mbWAQnyYAAiaxcqML6U359.jpg","title":"坐大飞艇vs劫持无人机 汽车之家欧洲挑战之旅","type":"原创","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":2,"fromtype":0},{"updatetime":"20161008070810","id":893702,"imgurl":"http://www2.autoimg.cn/newsdfs/g9/M01/5A/DC/640x320_0_autohomecar__wKgH0FfqMa6AWUVhAAiqPhomYBw135.jpg","title":"来得早不如来得巧 试驾丰田卡罗拉1.2T","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0},{"updatetime":"20161008070758","id":893484,"imgurl":"http://www3.autoimg.cn/newsdfs/g14/M0C/6A/A8/640x320_0_autohomecar__wKgH5Ff4NUyAXC85AAnrbDuofvY488.jpg","title":"越长越年轻 试北京现代悦纳1.4L 6AT","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0},{"updatetime":"20160928160424","id":55868682,"imgurl":"http://www2.autoimg.cn/newsdfs/g22/M08/3D/5A/640x320_0_autohomecar__wKjBwVfreYiAY0p4AAJGM3LUd8Y191.jpg","title":"空间大有安全感 分享博越提车感受","type":"","replycount":0,"pageindex":3788,"JumpType":0,"jumpurl":"","mediatype":4,"fromtype":0},{"updatetime":"20160929180407","id":55247505,"imgurl":"http://www2.autoimg.cn/newsdfs/g6/M14/5E/E1/640x320_0_autohomecar__wKgH3Ffs5xeAJr4CAAHeiUdliXQ370.jpg","title":"喜欢多年终圆夙愿 捷达1.6L购车记","type":"","replycount":0,"pageindex":16,"JumpType":0,"jumpurl":"","mediatype":4,"fromtype":0},{"updatetime":"20161008071054","id":893157,"imgurl":"http://www3.autoimg.cn/newsdfs/g11/M11/65/65/640x320_0_autohomecar__wKgH0lf3AR6Aa0BBAARm7aDjbIw122.jpg","title":"不一样的美好 穿越318国道川藏游记","type":"汽车文化","replycount":0,"pageindex":15,"JumpType":0,"jumpurl":"","mediatype":1,"fromtype":0}],"newslist":[{"id":539251,"title":"消费升级、更迭，小型车已成明日黄花？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M03/4A/8C/160x120_0_autohomecar__wKjBxFf4S2SAc6mNAARM6Dr4wzM592.jpg","replycount":1,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008092702"},{"id":893976,"title":"采用新品牌销售 曝更多大众电动车计划","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0D/6B/4B/160x120_0_autohomecar__wKgH41f4VZKATcE7AAE3892GX4M267.jpg","replycount":19,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008101154"},{"id":91328,"title":"内饰太骚气 定制版奥迪RS 7全面展示","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M0C/5C/28/240x180_0_autohomecar__wKgHy1ft_XiAOaDQAAETdf7vgqw835.jpg","replycount":27308,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930135153"},{"id":539273,"title":"差价6000元 帝豪GL离卡罗拉有多远？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M08/46/A3/160x120_0_autohomecar__wKgFVVf4U4-AOOP5AAFYUhVwruU332.jpg","replycount":176,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008100153"},{"id":893975,"title":"共9款车型 众泰SR9将于10月12日下线","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M15/4A/E1/160x120_0_autohomecar__wKjBwVf4SdiAHaM8AAEy_L0cQ70698.jpg","replycount":286,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008095709"},{"id":893974,"title":"或基于大众Amarok 斯柯达皮卡消息曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M07/4B/32/160x120_0_autohomecar__wKgFWFf4T-GAfVlkAAEMADiwQq0981.jpg","replycount":24,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094619"},{"id":539257,"title":"13-17万中端SUV在等待和呼唤自己的项羽","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/24/160x120_0_autohomecar__wKgFWFf4SDGAC4puAAPb7rOig4Q673.jpg","replycount":43,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008091322"},{"id":91366,"title":"运动版途观 外媒试驾西雅特Ateca 1.4T","mediatype":3,"type":"试车","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M11/60/57/240x180_0_autohomecar__wKjB01fuHtCAdQxTAAFS7NqIa8E756.jpg","replycount":13479,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930161415"},{"id":539236,"title":"修完就卖？卖家为何如此迫不及待！","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M03/69/D1/160x120_0_autohomecar__wKgH4Ff3IrKAVayrADBDLJIvHRA517.JPG","replycount":84,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007161915"},{"id":531667,"title":"【黑知识讲堂】有了Turbo还要VTEC吗？","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M06/69/0A/160x120_0_autohomecar__wKjB0Vf3stKAA_2VAAFLKhvkETQ485.jpg","replycount":148,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007223604"},{"id":91345,"title":"实在太任性了 实拍警车场地疯狂漂移","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0D/60/CD/240x180_0_autohomecar__wKgH5lfuBtqATKEkAAEooqv40PY904.jpg","replycount":13740,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143156"},{"id":539206,"title":"韩系动向，看韩系车前三季度销量如何","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/65/43/160x120_0_autohomecar__wKgH1Ff3B8mAM8EMAANn1SivonM997.jpg","replycount":386,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007162706"},{"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/160x120_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":155,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094801"},{"id":91351,"title":"霸气大尾翼 街拍橘色保时捷918 Spyder","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M0D/5D/71/240x180_0_autohomecar__wKgHzFfuBwKAQ8RKAAGC5y0SY-A038.jpg","replycount":18554,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143235"},{"id":54453553,"title":"选车是乐趣更是学习 提瑞风S2 1.5L","mediatype":5,"type":"a","time":"2016-10-08","indexdetail":"贵州论坛","smallpic":"http://club2.autoimg.cn/album/g14/M06/D7/AD/userphotos/2016/07/21/00/240180_wKgH5FePpHKANpFkAAEum0ZmjJY961.jpg","replycount":139,"pagecount":0,"jumppage":100008,"lasttime":"","newstype":0,"updatetime":"20161008070000"},{"id":538717,"title":"汽车江湖十五回:路虎发现5是神行Plus吗","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M05/46/41/160x120_0_autohomecar__wKgFV1f3BLqAQzrNAACAr0o74kc286.jpg","replycount":175,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007101317"},{"id":893967,"title":"Mustang Shelby GT350或配双离合变速箱","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M06/46/E7/160x120_0_autohomecar__wKgFVFf3QzyAM_qLAAEqLY302OQ982.jpg","replycount":123,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007152709"},{"id":893966,"title":"或达609马力 宝马M8新信息及假想图曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0C/65/C3/160x120_0_autohomecar__wKgH0lf3OIqAesV1AADTyETBot4234.jpg","replycount":175,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007215041"},{"id":893971,"title":"2017年推出 新一代欧宝Corsa谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M08/6D/53/160x120_0_autohomecar__wKgH3lf3mv-ARUWpAAGEU1zmcj0091.jpg","replycount":27,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007205430"},{"id":91348,"title":"路怒害人害己 两辆车逆行狂飙斗气互别","mediatype":3,"type":"花边","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/5C/EB/240x180_0_autohomecar__wKgH11fuBu-AJNhaAADml6wGFco256.jpg","replycount":61748,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143216"},{"id":893968,"title":"11月试营 雷诺自动驾驶示范区落户武汉","mediatype":1,"type":"新闻中心","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M07/6A/39/160x120_0_autohomecar__wKgH4Ff3YxqACJe-AAFqAImLz-o039.jpg","replycount":29,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008090247"},{"id":893973,"title":"周末改装车集锦第342期 日产改装车汇总","mediatype":1,"type":"改装/赛事","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M0B/65/6F/160x120_0_autohomecar__wKgH1Vf31o6AQtEpAAGIxU_I1Ho241.jpg","replycount":25,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008094016"},{"id":537732,"title":"三缸时代来临？盘点未来您的三缸座驾！","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g7/M09/69/A3/160x120_0_autohomecar__wKjB0Ff3Y3uAEqokAAFDUffHGus132.jpg","replycount":224,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007165740"},{"id":893960,"title":"形散神不散 避免审美疲劳的家族化设计","mediatype":1,"type":"技术设计","time":"2016-10-08","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/65/FD/160x120_0_autohomecar__wKgH11f3jUiAP_wtAAF9PJXVwUA953.jpg","replycount":102,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008100536"},{"id":532134,"title":"为何A6L/5系卖30多万 奔驰E级还是能赢","mediatype":2,"type":"","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M01/0D/F7/160x120_0_autohomecar__wKgH0Ve7lGGAZfLqAATGCLlRNuQ028.jpg","replycount":921,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007224045"},{"id":893702,"title":"来得早不如来得巧 试驾丰田卡罗拉1.2T","mediatype":1,"type":"试驾评测","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M13/5A/ED/160x120_0_autohomecar__wKgH3FfqMaqAXnqeAAHXSCPdemI465.jpg","replycount":576,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008095635"},{"id":893484,"title":"越长越年轻 试北京现代悦纳1.4L 6AT","mediatype":1,"type":"试驾评测","time":"2016-10-08","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M13/52/F5/160x120_0_autohomecar__wKgH4FfjSwiADOjpAAFHT8S_sn4272.jpg","replycount":365,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161008081333"},{"id":91346,"title":"玩得真尽兴 C 63 AMG/M5 E60场地漂移","mediatype":3,"type":"花边","time":"2016-10-07","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M06/5C/3B/240x180_0_autohomecar__wKgHy1fuBuKAXl8uAAEyWpgx-8c939.jpg","replycount":27283,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20160930143203"},{"id":539229,"title":"阿鲁的觉醒，铃木大R迎来重大换代！","mediatype":2,"type":"","time":"2016-10-07","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M04/68/77/160x120_0_autohomecar__wKgHz1f3EGWAa-mmAALQwlNIM88335.jpg","replycount":207,"pagecount":0,"jumppage":1,"lasttime":"","newstype":0,"updatetime":"20161007222848"},{"id":91342,"title":"很是过瘾 BAJA赛车征服各种糟糕路况","mediatype":3,"type":"花边","time":"2016-10-07","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M12/60/58/240x180_0_autohomecar__wKgH4VfuAJaAGGssAAEMd2igIoI942.jpg","replycount":23267,"pagecount":0,"jumppage":1,"lasttime":"201610072200574423272","newstype":0,"updatetime":"20160930140511"}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        /**
         * id : 893970
         * title : 新Q5/新5008等 巴黎车展将入华SUV盘点
         * mediatype : 1
         * type : 新闻中心
         * time : 2016-10-08
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/160x120_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg
         * replycount : 155
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         * updatetime : 20161008094801
         */

        private HeadlineinfoBean headlineinfo;
        private TopnewsinfoBean topnewsinfo;
        /**
         * updatetime : 20161007205146
         * id : 91387
         * imgurl : http://www3.autoimg.cn/newsdfs/g14/M0C/65/1D/640x320_0_autohomecar__wKgH1Vf3mbWAQnyYAAiaxcqML6U359.jpg
         * title : 坐大飞艇vs劫持无人机 汽车之家欧洲挑战之旅
         * type : 原创
         * replycount : 0
         * pageindex : 1
         * JumpType : 0
         * jumpurl :
         * mediatype : 2
         * fromtype : 0
         */

        private List<FocusimgBean> focusimg;
        /**
         * id : 539251
         * title : 消费升级、更迭，小型车已成明日黄花？
         * mediatype : 2
         * type :
         * time : 2016-10-08
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g19/M03/4A/8C/160x120_0_autohomecar__wKjBxFf4S2SAc6mNAARM6Dr4wzM592.jpg
         * replycount : 1
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         * newstype : 0
         * updatetime : 20161008092702
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public HeadlineinfoBean getHeadlineinfo() {
            return headlineinfo;
        }

        public void setHeadlineinfo(HeadlineinfoBean headlineinfo) {
            this.headlineinfo = headlineinfo;
        }

        public TopnewsinfoBean getTopnewsinfo() {
            return topnewsinfo;
        }

        public void setTopnewsinfo(TopnewsinfoBean topnewsinfo) {
            this.topnewsinfo = topnewsinfo;
        }

        public List<FocusimgBean> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<FocusimgBean> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class HeadlineinfoBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }
        }

        public static class TopnewsinfoBean {
        }

        public static class FocusimgBean {
            private String updatetime;
            private int id;
            private String imgurl;
            private String title;
            private String type;
            private int replycount;
            private int pageindex;
            private int JumpType;
            private String jumpurl;
            private int mediatype;
            private int fromtype;

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPageindex() {
                return pageindex;
            }

            public void setPageindex(int pageindex) {
                this.pageindex = pageindex;
            }

            public int getJumpType() {
                return JumpType;
            }

            public void setJumpType(int JumpType) {
                this.JumpType = JumpType;
            }

            public String getJumpurl() {
                return jumpurl;
            }

            public void setJumpurl(String jumpurl) {
                this.jumpurl = jumpurl;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public int getFromtype() {
                return fromtype;
            }

            public void setFromtype(int fromtype) {
                this.fromtype = fromtype;
            }
        }

        public static class NewslistBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }
        }
    }
}
