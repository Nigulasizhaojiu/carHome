package com.example.dllo.recommend.tv;

import java.util.List;

/**
 * Created by dllo on 16/10/9.
 */
public class TvBean {
    /**
     * isloadmore : true
     * rowcount : 76762
     * pagecount : 2477
     * pageindex : 0
     * list : [{"id":91471,"title":"全是狠车！多辆热门超跑上演直线大战","type":"花边","time":"2016-10-09","indexdetail":"视频中675LT/570S/大牛SV/法拉利F12/911GT3 RS/918/570S/Huracan等多辆顶级超跑，展开直线对决，你猜谁赢了？","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M08/69/FE/120x90_0_autohomecar__wKjB0Vf4ko2AOjUXAAEijgy1v-A060.jpg","replycount":254,"playcount":43316,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91471.html","updatetime":"20161009091749","lastid":"201610090031442016100916430891471"},{"id":91543,"title":"远光真要命 高速夜行视线受阻惨撞车","type":"花边","time":"2016-10-09","indexdetail":"都是远光惹的祸！高速夜行视线受阻撞车。","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M04/6D/80/120x90_0_autohomecar__wKgH3Vf5q-SAXmamAABLIoytIOI488.jpg","replycount":107,"playcount":10926,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91543.html","updatetime":"20161009131144","lastid":"201610091031012016100916430891543"},{"id":91467,"title":"针锋相对 全新奥迪R8大战迈凯伦570S","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是奥迪R8大战迈凯伦570S，快来看看谁更强？","smallimg":"http://www3.autoimg.cn/newsdfs/g22/M09/4B/75/120x90_0_autohomecar__wKjBwVf4jYyAfLsWAAEqnvdtAaY396.jpg","replycount":134,"playcount":26672,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91467.html","updatetime":"20161008140917","lastid":"201610090010482016100916430791467"},{"id":91547,"title":"主要跟开口有关系 三大敞篷车淋雨测试","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了三辆敞篷车面对雨天的场面，我想主要还是跟开口的大小有关系，你觉着呢？","smallimg":"http://www3.autoimg.cn/newsdfs/g12/M01/6E/A5/120x90_0_autohomecar__wKgH4lf5rRuAFGYcAAGWg__8iQc434.jpg","replycount":4,"playcount":2682,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91547.html","updatetime":"20161009103612","lastid":"201610091036122016100916430791547"},{"id":91551,"title":"豪华座驾登场 华人美女试驾沃尔沃S90","type":"花边","time":"2016-10-09","indexdetail":"<div>外观方面，沃尔沃S90采用最新的家族式前脸设计，直瀑式的进气格栅运用内凹式设计。\u201c雷神之锤\u201d的前大灯非常犀利。\u201cC\u201d字形的尾灯具备很高的辨识度，排气孔为扁口状，且为双边共两出的布局。车身尺寸方面，它的长/宽/高分别为分别为4963×1890×1443mm，轴距为2941mm。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0C/68/91/120x90_0_autohomecar__wKgH11f5rzKAVwF9AAE-h8Lbf5U252.jpg","replycount":22,"playcount":6778,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91551.html","updatetime":"20161009164423","lastid":"201610091644232016100916430791551"},{"id":91557,"title":"看着解气 宝马SUV超车后玩急刹被怒怼","type":"花边","time":"2016-10-09","indexdetail":"视频中超车后的SUV急刹被后车直接硬怼，实在是够狠！","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M08/48/88/120x90_0_autohomecar__wKgFVVf5tBKAcGHDAAEczepB2LU223.jpg","replycount":61,"playcount":36753,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91557.html","updatetime":"20161009110555","lastid":"201610091105542016100916430791557"},{"id":91489,"title":"小面也疯狂 五菱荣光后驱车漂移视频","type":"花边","time":"2016-10-09","indexdetail":"小面也疯狂，涛神教你用五菱宏光学漂移。学会了它，分分钟变车神，从此再也不怕秋明山上的GT-R了！","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M10/66/3A/120x90_0_autohomecar__wKjBzlf5qtaAGu1gAAEF45cGFhs807.jpg","replycount":49,"playcount":24807,"nickname":"许云鹤","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91489.html","updatetime":"20161009102924","lastid":"201610091026352016100916430791489"},{"id":91555,"title":"差点悲剧了！俄罗斯加油站起火赶紧扑灭","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了加油站起火赶紧被扑灭了，幸亏这个灭火器比较给力！","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M0A/66/49/120x90_0_autohomecar__wKjBzlf5ss2ARHR0AAEnzMWzAvo660.jpg","replycount":36,"playcount":7261,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91555.html","updatetime":"20161009110033","lastid":"201610091100332016100916430791555"},{"id":91550,"title":"抬头很轻松 直线加速赛车凶猛起步合集","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了直线加速赛车的凶猛起步合集。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M04/4A/19/120x90_0_autohomecar__wKgFVlf5rseAU9npAAFP-a02uAE559.jpg","replycount":4,"playcount":6772,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91550.html","updatetime":"20161009104320","lastid":"201610091043202016100916430791550"},{"id":91553,"title":"实在太稀有！街头实拍奔驰S600 Royale","type":"花边","time":"2016-10-09","indexdetail":"视频中展示的是一辆奔驰S600 Royale。据说该车是<span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;;\">w222的底子，s级的侧身，slr的侧进气口，sls的前后灯。<\/span>","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M10/6C/2C/120x90_0_autohomecar__wKjBxVf5seqAG7_pAAGPiPb8jxY779.jpg","replycount":12,"playcount":8137,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91553.html","updatetime":"20161009165041","lastid":"201610091056442016100916430791553"},{"id":91532,"title":"应该是个新手 女警官开摩托上拖车翻车","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了女警官开摩托上拖车翻车的画面。","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M12/6C/B8/120x90_0_autohomecar__wKjBylf5poSAe_ehAAEA94U0O0s007.jpg","replycount":24,"playcount":18893,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91532.html","updatetime":"20161009100806","lastid":"201610091008062016100916430791532"},{"id":91548,"title":"听着就过瘾 V8发动机排气声浪大合集","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了V8发动机的排气声浪大合集。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g18/M05/6C/C3/120x90_0_autohomecar__wKgH6Ff5rYmAJORXAAFXKoUU1_4953.jpg","replycount":15,"playcount":11166,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91548.html","updatetime":"20161009103802","lastid":"201610091038022016100916430791548"},{"id":91470,"title":"四驱也能漂？奥迪RS 6湿地艰难尝试漂移","type":"花边","time":"2016-10-09","indexdetail":"视频中一辆奥迪RS 6湿地艰难尝试漂移，简直太难了，有可能是技术问题。","smallimg":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/21/120x90_0_autohomecar__wKjBxFf4kXSAVN8KAAEmJpTiyrE888.jpg","replycount":169,"playcount":30725,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91470.html","updatetime":"20161008142559","lastid":"201610090023072016100916430791470"},{"id":91469,"title":"带你探访！全新奥迪Q5墨西哥工厂展示","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是全新奥迪Q5墨西哥工厂展示。","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M10/6B/F6/120x90_0_autohomecar__wKjByFf4j2iAM_DAAAHQINpftJc641.jpg","replycount":102,"playcount":45057,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91469.html","updatetime":"20161008141713","lastid":"201610090017032016100916430791469"},{"id":91511,"title":"科技感十足 雷克萨斯UX动画版宣传片","type":"广告","time":"2016-10-09","indexdetail":"外观方面，UX概念车使用\u201c紫水晶\u201d漆面，而造型采用了家族化设计，整体线条的力量感和设计感都很强。车身大量的复杂线条设计，也与同胞NX、RX等车型非常相似。透明的A柱设计使得驾驶员的视野更加开阔，而21英寸的密条辐式轮圈采用了与轮胎花纹相融合的纹路设计，样式非常新颖。","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M13/68/43/120x90_0_autohomecar__wKgHzlf5oZyATde4AAEtbJWKugc985.jpg","replycount":7,"playcount":1413,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_3_91511.html","updatetime":"20161009094713","lastid":"201610090947132016100913074291511"},{"id":91523,"title":"动作娴熟帅气 斯巴鲁BRZ场地内秀漂移","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了斯巴鲁BRZ场地内秀漂移的画面。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g5/M0A/6D/B6/120x90_0_autohomecar__wKgH21f5pMyAVSZuAAD_b-cU29E574.jpg","replycount":2,"playcount":1030,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91523.html","updatetime":"20161009100045","lastid":"201610091000452016100913074291523"},{"id":91522,"title":"撞开发动机盖 实录路口两轿车猛烈相撞","type":"花边","time":"2016-10-09","indexdetail":"视频实录了路口内两轿车猛烈相撞，其中一辆车的发动机盖都被撞了起来。","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M11/4D/C8/120x90_0_autohomecar__wKgFW1f5pJ6AfHc8AAEuVKdgAt4695.jpg","replycount":7,"playcount":2363,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91522.html","updatetime":"20161009100000","lastid":"201610091000002016100913074291522"},{"id":91519,"title":"凶狠的外观 LARTE Design改奔驰GLS","type":"花边","time":"2016-10-09","indexdetail":"<div>以马蹄铁作为品牌LOGO的汽车改装公司LARTE Design近日推出了奔驰GLS改装案例，为这款大型SUV设计了一套宽体套件和轮圈。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/68/C5/120x90_0_autohomecar__wKgH0lf5pFqAbDEWAAFkgzbUmSU910.jpg","replycount":1,"playcount":1995,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91519.html","updatetime":"20161009095852","lastid":"201610090958522016100913074291519"},{"id":91537,"title":"1:8超大模型 乐高版保时捷911 GT3 RS","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了保时捷911 GT3 RS的乐高模型。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g11/M10/68/D2/120x90_0_autohomecar__wKgH0lf5qK6AW4bOAAG25Jf5JuE685.jpg","replycount":2,"playcount":852,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91537.html","updatetime":"20161009101720","lastid":"201610091017202016100913074291537"},{"id":91525,"title":"群雄逐鹿 改装雷克萨斯RC F拼直线加速","type":"花边","time":"2016-10-09","indexdetail":"视频展示了改装雷克萨斯RC F拼直线加速的画面。","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M00/4C/A6/120x90_0_autohomecar__wKgFWlf5pS6AWq5xAAElTmL_-cE286.jpg","replycount":2,"playcount":556,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91525.html","updatetime":"20161009100224","lastid":"201610091002242016100913074291525"},{"id":91559,"title":"近距离感受 宝马新一代5系伪装动态试车","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是宝马新一代5系动态试车的画面，虽然还有伪装，但是可以感受到它的动态姿态。","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/6C/28/120x90_0_autohomecar__wKjBzFf5ta2AQ1ykAADkh4eGV_8018.jpg","replycount":11,"playcount":1942,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91559.html","updatetime":"20161009112155","lastid":"201610091112462016100913074291559"},{"id":91554,"title":"实力的体现 街拍Mansory改装奔驰G 500","type":"花边","time":"2016-10-09","indexdetail":"视频中展示的是一辆Mansory改装奔驰G 500，外形太霸气了！","smallimg":"http://www2.autoimg.cn/newsdfs/g16/M03/68/98/120x90_0_autohomecar__wKgH11f5skOARp_8AAFM60w9zZE538.jpg","replycount":2,"playcount":4846,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91554.html","updatetime":"20161009132201","lastid":"201610091058122016100913074291554"},{"id":91526,"title":"声浪特别骚！改装性能车/超跑大聚会","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了改装性能车/超跑聚会的画面。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g19/M12/4D/0D/120x90_0_autohomecar__wKgFWFf5pUWALvO3AAGKBXg08vM759.jpg","replycount":0,"playcount":1191,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91526.html","updatetime":"20161009100247","lastid":"201610091002472016100913074291526"},{"id":91513,"title":"没有提前减速 小轿车在斑马线撞飞行人","type":"花边","time":"2016-10-09","indexdetail":"视频中一辆黑色小轿车在斑马线前没有减速，直接撞飞了过马路的行人。","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M12/67/7C/120x90_0_autohomecar__wKgHzVf5ot6AKiCrAAFI90k20zU104.jpg","replycount":3,"playcount":2183,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91513.html","updatetime":"20161009095231","lastid":"201610090952302016100913074291513"},{"id":91539,"title":"能上路的赛车 详细介绍KTM X-BOW GT","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了KTM X-BOW GT的详细介绍。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M09/6D/25/120x90_0_autohomecar__wKgH5lf5qVmAI8Y1AAHIWY0gZdw879.jpg","replycount":3,"playcount":1748,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91539.html","updatetime":"20161009102010","lastid":"201610091020102016100913074291539"},{"id":91530,"title":"高尔夫亮了 挑战者SRT Hellcat直线狂飙","type":"花边","time":"2016-10-09","indexdetail":"视频展示了挑战者SRT Hellcat/SRT8直线加速战群雄。","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0C/68/79/120x90_0_autohomecar__wKgH11f5pjqAKgXKAAEHfc4tvec518.jpg","replycount":2,"playcount":1994,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91530.html","updatetime":"20161009100651","lastid":"201610091006512016100913074291530"},{"id":91533,"title":"硬派越野 帕杰罗全时四驱系统宣传片","type":"广告","time":"2016-10-09","indexdetail":"<div>视频展示了帕杰罗全时四驱系统的宣传片。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M00/4C/30/120x90_0_autohomecar__wKjBw1f5pw6AU27WAAFZqd0jkTI374.jpg","replycount":6,"playcount":3777,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_3_91533.html","updatetime":"20161009101029","lastid":"201610091010292016100913074291533"},{"id":91521,"title":"全新奥迪A8 D5 伪装车纽北赛道路试","type":"花边","time":"2016-10-09","indexdetail":"全新奥迪A8上或将首次搭载自动驾驶功能，其配备的交通堵塞辅助系统可使车辆能够以60km/h的最高速度进行自动驾驶。动力方面，预计全新奥迪A8将搭载2.0T和3.0T发动机，此外作为旗舰车型，W12发动机预计也将继续出现在车系当中。","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M02/6C/97/120x90_0_autohomecar__wKgH4Vf5pIaAErT3AAE0AZvmvXc227.jpg","replycount":3,"playcount":735,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91521.html","updatetime":"20161009095935","lastid":"201610090959352016100913074291521"},{"id":91541,"title":"变异大黄蜂 2016款科迈罗SS直线拼加速","type":"花边","time":"2016-10-09","indexdetail":"视频展示了2016款科迈罗SS直线拼加速的画面。","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M06/6C/8B/120x90_0_autohomecar__wKjB01f5quKATG9ZAAEE8UQGacY025.jpg","replycount":1,"playcount":1465,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91541.html","updatetime":"20161009102644","lastid":"201610091026442016100913074291541"},{"id":91527,"title":"跟车距离过近 摄像车遭遇连环追尾事故","type":"花边","time":"2016-10-09","indexdetail":"视频实录了高速公路上发生拥堵时，摄像车遭遇连环追尾事故，如果大家都能将车距拉开，就会降低连环追尾事故的发生概率。","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M0A/70/F1/120x90_0_autohomecar__wKgH31f5pYSAJYgdAAFEp28YYso078.jpg","replycount":174,"playcount":39602,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91527.html","updatetime":"20161009100350","lastid":"201610091003502016100913074291527"}]
     */

    private ResultBean result;
    /**
     * result : {"isloadmore":true,"rowcount":76762,"pagecount":2477,"pageindex":0,"list":[{"id":91471,"title":"全是狠车！多辆热门超跑上演直线大战","type":"花边","time":"2016-10-09","indexdetail":"视频中675LT/570S/大牛SV/法拉利F12/911GT3 RS/918/570S/Huracan等多辆顶级超跑，展开直线对决，你猜谁赢了？","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M08/69/FE/120x90_0_autohomecar__wKjB0Vf4ko2AOjUXAAEijgy1v-A060.jpg","replycount":254,"playcount":43316,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91471.html","updatetime":"20161009091749","lastid":"201610090031442016100916430891471"},{"id":91543,"title":"远光真要命 高速夜行视线受阻惨撞车","type":"花边","time":"2016-10-09","indexdetail":"都是远光惹的祸！高速夜行视线受阻撞车。","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M04/6D/80/120x90_0_autohomecar__wKgH3Vf5q-SAXmamAABLIoytIOI488.jpg","replycount":107,"playcount":10926,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91543.html","updatetime":"20161009131144","lastid":"201610091031012016100916430891543"},{"id":91467,"title":"针锋相对 全新奥迪R8大战迈凯伦570S","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是奥迪R8大战迈凯伦570S，快来看看谁更强？","smallimg":"http://www3.autoimg.cn/newsdfs/g22/M09/4B/75/120x90_0_autohomecar__wKjBwVf4jYyAfLsWAAEqnvdtAaY396.jpg","replycount":134,"playcount":26672,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91467.html","updatetime":"20161008140917","lastid":"201610090010482016100916430791467"},{"id":91547,"title":"主要跟开口有关系 三大敞篷车淋雨测试","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了三辆敞篷车面对雨天的场面，我想主要还是跟开口的大小有关系，你觉着呢？","smallimg":"http://www3.autoimg.cn/newsdfs/g12/M01/6E/A5/120x90_0_autohomecar__wKgH4lf5rRuAFGYcAAGWg__8iQc434.jpg","replycount":4,"playcount":2682,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91547.html","updatetime":"20161009103612","lastid":"201610091036122016100916430791547"},{"id":91551,"title":"豪华座驾登场 华人美女试驾沃尔沃S90","type":"花边","time":"2016-10-09","indexdetail":"<div>外观方面，沃尔沃S90采用最新的家族式前脸设计，直瀑式的进气格栅运用内凹式设计。\u201c雷神之锤\u201d的前大灯非常犀利。\u201cC\u201d字形的尾灯具备很高的辨识度，排气孔为扁口状，且为双边共两出的布局。车身尺寸方面，它的长/宽/高分别为分别为4963×1890×1443mm，轴距为2941mm。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0C/68/91/120x90_0_autohomecar__wKgH11f5rzKAVwF9AAE-h8Lbf5U252.jpg","replycount":22,"playcount":6778,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91551.html","updatetime":"20161009164423","lastid":"201610091644232016100916430791551"},{"id":91557,"title":"看着解气 宝马SUV超车后玩急刹被怒怼","type":"花边","time":"2016-10-09","indexdetail":"视频中超车后的SUV急刹被后车直接硬怼，实在是够狠！","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M08/48/88/120x90_0_autohomecar__wKgFVVf5tBKAcGHDAAEczepB2LU223.jpg","replycount":61,"playcount":36753,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91557.html","updatetime":"20161009110555","lastid":"201610091105542016100916430791557"},{"id":91489,"title":"小面也疯狂 五菱荣光后驱车漂移视频","type":"花边","time":"2016-10-09","indexdetail":"小面也疯狂，涛神教你用五菱宏光学漂移。学会了它，分分钟变车神，从此再也不怕秋明山上的GT-R了！","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M10/66/3A/120x90_0_autohomecar__wKjBzlf5qtaAGu1gAAEF45cGFhs807.jpg","replycount":49,"playcount":24807,"nickname":"许云鹤","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91489.html","updatetime":"20161009102924","lastid":"201610091026352016100916430791489"},{"id":91555,"title":"差点悲剧了！俄罗斯加油站起火赶紧扑灭","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了加油站起火赶紧被扑灭了，幸亏这个灭火器比较给力！","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M0A/66/49/120x90_0_autohomecar__wKjBzlf5ss2ARHR0AAEnzMWzAvo660.jpg","replycount":36,"playcount":7261,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91555.html","updatetime":"20161009110033","lastid":"201610091100332016100916430791555"},{"id":91550,"title":"抬头很轻松 直线加速赛车凶猛起步合集","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了直线加速赛车的凶猛起步合集。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M04/4A/19/120x90_0_autohomecar__wKgFVlf5rseAU9npAAFP-a02uAE559.jpg","replycount":4,"playcount":6772,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91550.html","updatetime":"20161009104320","lastid":"201610091043202016100916430791550"},{"id":91553,"title":"实在太稀有！街头实拍奔驰S600 Royale","type":"花边","time":"2016-10-09","indexdetail":"视频中展示的是一辆奔驰S600 Royale。据说该车是<span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;;\">w222的底子，s级的侧身，slr的侧进气口，sls的前后灯。<\/span>","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M10/6C/2C/120x90_0_autohomecar__wKjBxVf5seqAG7_pAAGPiPb8jxY779.jpg","replycount":12,"playcount":8137,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91553.html","updatetime":"20161009165041","lastid":"201610091056442016100916430791553"},{"id":91532,"title":"应该是个新手 女警官开摩托上拖车翻车","type":"花边","time":"2016-10-09","indexdetail":"视频中展示了女警官开摩托上拖车翻车的画面。","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M12/6C/B8/120x90_0_autohomecar__wKjBylf5poSAe_ehAAEA94U0O0s007.jpg","replycount":24,"playcount":18893,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91532.html","updatetime":"20161009100806","lastid":"201610091008062016100916430791532"},{"id":91548,"title":"听着就过瘾 V8发动机排气声浪大合集","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了V8发动机的排气声浪大合集。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g18/M05/6C/C3/120x90_0_autohomecar__wKgH6Ff5rYmAJORXAAFXKoUU1_4953.jpg","replycount":15,"playcount":11166,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91548.html","updatetime":"20161009103802","lastid":"201610091038022016100916430791548"},{"id":91470,"title":"四驱也能漂？奥迪RS 6湿地艰难尝试漂移","type":"花边","time":"2016-10-09","indexdetail":"视频中一辆奥迪RS 6湿地艰难尝试漂移，简直太难了，有可能是技术问题。","smallimg":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/21/120x90_0_autohomecar__wKjBxFf4kXSAVN8KAAEmJpTiyrE888.jpg","replycount":169,"playcount":30725,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91470.html","updatetime":"20161008142559","lastid":"201610090023072016100916430791470"},{"id":91469,"title":"带你探访！全新奥迪Q5墨西哥工厂展示","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是全新奥迪Q5墨西哥工厂展示。","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M10/6B/F6/120x90_0_autohomecar__wKjByFf4j2iAM_DAAAHQINpftJc641.jpg","replycount":102,"playcount":45057,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91469.html","updatetime":"20161008141713","lastid":"201610090017032016100916430791469"},{"id":91511,"title":"科技感十足 雷克萨斯UX动画版宣传片","type":"广告","time":"2016-10-09","indexdetail":"外观方面，UX概念车使用\u201c紫水晶\u201d漆面，而造型采用了家族化设计，整体线条的力量感和设计感都很强。车身大量的复杂线条设计，也与同胞NX、RX等车型非常相似。透明的A柱设计使得驾驶员的视野更加开阔，而21英寸的密条辐式轮圈采用了与轮胎花纹相融合的纹路设计，样式非常新颖。","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M13/68/43/120x90_0_autohomecar__wKgHzlf5oZyATde4AAEtbJWKugc985.jpg","replycount":7,"playcount":1413,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_3_91511.html","updatetime":"20161009094713","lastid":"201610090947132016100913074291511"},{"id":91523,"title":"动作娴熟帅气 斯巴鲁BRZ场地内秀漂移","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了斯巴鲁BRZ场地内秀漂移的画面。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g5/M0A/6D/B6/120x90_0_autohomecar__wKgH21f5pMyAVSZuAAD_b-cU29E574.jpg","replycount":2,"playcount":1030,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91523.html","updatetime":"20161009100045","lastid":"201610091000452016100913074291523"},{"id":91522,"title":"撞开发动机盖 实录路口两轿车猛烈相撞","type":"花边","time":"2016-10-09","indexdetail":"视频实录了路口内两轿车猛烈相撞，其中一辆车的发动机盖都被撞了起来。","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M11/4D/C8/120x90_0_autohomecar__wKgFW1f5pJ6AfHc8AAEuVKdgAt4695.jpg","replycount":7,"playcount":2363,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91522.html","updatetime":"20161009100000","lastid":"201610091000002016100913074291522"},{"id":91519,"title":"凶狠的外观 LARTE Design改奔驰GLS","type":"花边","time":"2016-10-09","indexdetail":"<div>以马蹄铁作为品牌LOGO的汽车改装公司LARTE Design近日推出了奔驰GLS改装案例，为这款大型SUV设计了一套宽体套件和轮圈。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/68/C5/120x90_0_autohomecar__wKgH0lf5pFqAbDEWAAFkgzbUmSU910.jpg","replycount":1,"playcount":1995,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91519.html","updatetime":"20161009095852","lastid":"201610090958522016100913074291519"},{"id":91537,"title":"1:8超大模型 乐高版保时捷911 GT3 RS","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了保时捷911 GT3 RS的乐高模型。<\/div>","smallimg":"http://www2.autoimg.cn/newsdfs/g11/M10/68/D2/120x90_0_autohomecar__wKgH0lf5qK6AW4bOAAG25Jf5JuE685.jpg","replycount":2,"playcount":852,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91537.html","updatetime":"20161009101720","lastid":"201610091017202016100913074291537"},{"id":91525,"title":"群雄逐鹿 改装雷克萨斯RC F拼直线加速","type":"花边","time":"2016-10-09","indexdetail":"视频展示了改装雷克萨斯RC F拼直线加速的画面。","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M00/4C/A6/120x90_0_autohomecar__wKgFWlf5pS6AWq5xAAElTmL_-cE286.jpg","replycount":2,"playcount":556,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91525.html","updatetime":"20161009100224","lastid":"201610091002242016100913074291525"},{"id":91559,"title":"近距离感受 宝马新一代5系伪装动态试车","type":"花边","time":"2016-10-09","indexdetail":"视频中带来的是宝马新一代5系动态试车的画面，虽然还有伪装，但是可以感受到它的动态姿态。","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/6C/28/120x90_0_autohomecar__wKjBzFf5ta2AQ1ykAADkh4eGV_8018.jpg","replycount":11,"playcount":1942,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91559.html","updatetime":"20161009112155","lastid":"201610091112462016100913074291559"},{"id":91554,"title":"实力的体现 街拍Mansory改装奔驰G 500","type":"花边","time":"2016-10-09","indexdetail":"视频中展示的是一辆Mansory改装奔驰G 500，外形太霸气了！","smallimg":"http://www2.autoimg.cn/newsdfs/g16/M03/68/98/120x90_0_autohomecar__wKgH11f5skOARp_8AAFM60w9zZE538.jpg","replycount":2,"playcount":4846,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91554.html","updatetime":"20161009132201","lastid":"201610091058122016100913074291554"},{"id":91526,"title":"声浪特别骚！改装性能车/超跑大聚会","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了改装性能车/超跑聚会的画面。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g19/M12/4D/0D/120x90_0_autohomecar__wKgFWFf5pUWALvO3AAGKBXg08vM759.jpg","replycount":0,"playcount":1191,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91526.html","updatetime":"20161009100247","lastid":"201610091002472016100913074291526"},{"id":91513,"title":"没有提前减速 小轿车在斑马线撞飞行人","type":"花边","time":"2016-10-09","indexdetail":"视频中一辆黑色小轿车在斑马线前没有减速，直接撞飞了过马路的行人。","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M12/67/7C/120x90_0_autohomecar__wKgHzVf5ot6AKiCrAAFI90k20zU104.jpg","replycount":3,"playcount":2183,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91513.html","updatetime":"20161009095231","lastid":"201610090952302016100913074291513"},{"id":91539,"title":"能上路的赛车 详细介绍KTM X-BOW GT","type":"花边","time":"2016-10-09","indexdetail":"<div>视频展示了KTM X-BOW GT的详细介绍。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M09/6D/25/120x90_0_autohomecar__wKgH5lf5qVmAI8Y1AAHIWY0gZdw879.jpg","replycount":3,"playcount":1748,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91539.html","updatetime":"20161009102010","lastid":"201610091020102016100913074291539"},{"id":91530,"title":"高尔夫亮了 挑战者SRT Hellcat直线狂飙","type":"花边","time":"2016-10-09","indexdetail":"视频展示了挑战者SRT Hellcat/SRT8直线加速战群雄。","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0C/68/79/120x90_0_autohomecar__wKgH11f5pjqAKgXKAAEHfc4tvec518.jpg","replycount":2,"playcount":1994,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91530.html","updatetime":"20161009100651","lastid":"201610091006512016100913074291530"},{"id":91533,"title":"硬派越野 帕杰罗全时四驱系统宣传片","type":"广告","time":"2016-10-09","indexdetail":"<div>视频展示了帕杰罗全时四驱系统的宣传片。<\/div>","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M00/4C/30/120x90_0_autohomecar__wKjBw1f5pw6AU27WAAFZqd0jkTI374.jpg","replycount":6,"playcount":3777,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_3_91533.html","updatetime":"20161009101029","lastid":"201610091010292016100913074291533"},{"id":91521,"title":"全新奥迪A8 D5 伪装车纽北赛道路试","type":"花边","time":"2016-10-09","indexdetail":"全新奥迪A8上或将首次搭载自动驾驶功能，其配备的交通堵塞辅助系统可使车辆能够以60km/h的最高速度进行自动驾驶。动力方面，预计全新奥迪A8将搭载2.0T和3.0T发动机，此外作为旗舰车型，W12发动机预计也将继续出现在车系当中。","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M02/6C/97/120x90_0_autohomecar__wKgH4Vf5pIaAErT3AAE0AZvmvXc227.jpg","replycount":3,"playcount":735,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91521.html","updatetime":"20161009095935","lastid":"201610090959352016100913074291521"},{"id":91541,"title":"变异大黄蜂 2016款科迈罗SS直线拼加速","type":"花边","time":"2016-10-09","indexdetail":"视频展示了2016款科迈罗SS直线拼加速的画面。","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M06/6C/8B/120x90_0_autohomecar__wKjB01f5quKATG9ZAAEE8UQGacY025.jpg","replycount":1,"playcount":1465,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91541.html","updatetime":"20161009102644","lastid":"201610091026442016100913074291541"},{"id":91527,"title":"跟车距离过近 摄像车遭遇连环追尾事故","type":"花边","time":"2016-10-09","indexdetail":"视频实录了高速公路上发生拥堵时，摄像车遭遇连环追尾事故，如果大家都能将车距拉开，就会降低连环追尾事故的发生概率。","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M0A/70/F1/120x90_0_autohomecar__wKgH31f5pYSAJYgdAAFEp28YYso078.jpg","replycount":174,"playcount":39602,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_91527.html","updatetime":"20161009100350","lastid":"201610091003502016100913074291527"}]}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private boolean isloadmore;
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 91471
         * title : 全是狠车！多辆热门超跑上演直线大战
         * type : 花边
         * time : 2016-10-09
         * indexdetail : 视频中675LT/570S/大牛SV/法拉利F12/911GT3 RS/918/570S/Huracan等多辆顶级超跑，展开直线对决，你猜谁赢了？
         * smallimg : http://www3.autoimg.cn/newsdfs/g6/M08/69/FE/120x90_0_autohomecar__wKjB0Vf4ko2AOjUXAAEijgy1v-A060.jpg
         * replycount : 254
         * playcount : 43316
         * nickname : 郭泽松
         * videoaddress : http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8
         * shareaddress : http://v.autohome.com.cn/v_4_91471.html
         * updatetime : 20161009091749
         * lastid : 201610090031442016100916430891471
         */

        private List<ListBean> list;

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int id;
            private String title;
            private String type;
            private String time;
            private String indexdetail;
            private String smallimg;
            private int replycount;
            private int playcount;
            private String nickname;
            private String videoaddress;
            private String shareaddress;
            private String updatetime;
            private String lastid;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallimg() {
                return smallimg;
            }

            public void setSmallimg(String smallimg) {
                this.smallimg = smallimg;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPlaycount() {
                return playcount;
            }

            public void setPlaycount(int playcount) {
                this.playcount = playcount;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getVideoaddress() {
                return videoaddress;
            }

            public void setVideoaddress(String videoaddress) {
                this.videoaddress = videoaddress;
            }

            public String getShareaddress() {
                return shareaddress;
            }

            public void setShareaddress(String shareaddress) {
                this.shareaddress = shareaddress;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public String getLastid() {
                return lastid;
            }

            public void setLastid(String lastid) {
                this.lastid = lastid;
            }
        }
    }
}
