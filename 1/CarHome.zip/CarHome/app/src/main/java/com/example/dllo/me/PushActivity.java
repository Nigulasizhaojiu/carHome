package com.example.dllo.me;

import com.example.dllo.carhome.BaseAty;
import com.example.dllo.carhome.R;

/**
 * Created by dllo on 16/10/13.
 */
public class PushActivity extends BaseAty{
    @Override
    protected int setLayout() {
        return R.layout.push_activity;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
