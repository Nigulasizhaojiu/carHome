package com.example.dllo.forum.allselected;

import java.util.List;

/**
 * Created by dllo on 16/9/22.
 */
public class AllSelectedBean {

    /**
     * message :
     * returncode : 0
     * result : {"pageindex":1,"pagecount":27,"rowcount":791,"list":[{"topicid":56254930,"title":"幸福因为有你 媳妇与爱车的机场秀","lastreplydate":"1分钟前","postusername":"大改变成就超超","replycounts":55,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M00/52/BA/userphotos/2016/09/21/21/240180_wKgH3VfiixmAacavAAI4Tih4rEw840.jpg","topictype":"精","views":17941,"postmemberid":0,"imgurl":"","bbsid":200226,"bbstype":"o","bbsname":"媳妇当车模791季"},{"topicid":55749571,"title":"一路走来有苦有乐 辣妈出镜当车模","lastreplydate":"4分钟前","postusername":"86866449我","replycounts":2260,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M06/52/76/userphotos/2016/09/21/21/240180_wKjByFfii4qAVX7yAAMkwCkI0cA994.jpg","topictype":"精","views":521216,"postmemberid":0,"imgurl":"","bbsid":2228,"bbstype":"c","bbsname":"媳妇当车模790季"},{"topicid":55837020,"title":"清新抑或是妩媚 娇俏女友百变出场","lastreplydate":"10分钟前","postusername":"alex_cool9","replycounts":1967,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M0C/32/CA/userphotos/2016/09/21/21/240180_wKjBwFfijieAPJH4AALa-IGqp8w133.jpg","topictype":"精","views":664558,"postmemberid":0,"imgurl":"","bbsid":3043,"bbstype":"c","bbsname":"媳妇当车模789季"},{"topicid":55106505,"title":"做个有福之人 俏丽媳妇携爱车出镜","lastreplydate":"14分钟前","postusername":"xujinle","replycounts":697,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M01/50/3E/userphotos/2016/09/21/21/240180_wKjByVfijrCADpZvAAMMKDQlkeA087.jpg","topictype":"精","views":556332,"postmemberid":0,"imgurl":"","bbsid":117,"bbstype":"c","bbsname":"媳妇当车模788季"},{"topicid":55759139,"title":"多口之家之选 气质媳妇助阵华颂7","lastreplydate":"44分钟前","postusername":"沈阳_大海","replycounts":554,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M0B/51/CE/userphotos/2016/09/21/21/240180_wKgH6FfijwKAXLT6AAXH-rBGH7U181.jpg","topictype":"精","views":553697,"postmemberid":0,"imgurl":"","bbsid":3607,"bbstype":"c","bbsname":"媳妇当车模787季"},{"topicid":55049520,"title":"两年始终相伴 俏美媳妇与爱车出境","lastreplydate":"2分钟前","postusername":"Colin_Joe","replycounts":1163,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M0D/D5/2C/userphotos/2016/08/09/08/240180_wKgFVFepI1GAfBWyAAFElUxmSnw437.jpg","topictype":"精","views":1003936,"postmemberid":0,"imgurl":"","bbsid":905,"bbstype":"c","bbsname":"媳妇当车模786季"},{"topicid":55118940,"title":"省油是关键 纯情软妹助阵雷凌双擎","lastreplydate":"9小时前","postusername":"提车电闪雷鸣","replycounts":815,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M07/F7/09/userphotos/2016/08/16/16/240180_wKjBz1eyzGKAOZGrAAFF_uEsM3Q740.jpg","topictype":"精","views":868809,"postmemberid":0,"imgurl":"","bbsid":3462,"bbstype":"c","bbsname":"媳妇当车模785季"},{"topicid":55116147,"title":"博瑞的深情 抵不住\u201c女王\u201d的姿态","lastreplydate":"10分钟前","postusername":"Hesir516","replycounts":841,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g21/M0A/D7/7C/userphotos/2016/08/11/14/240180_wKgFVVesGmOAdIBZAAE6Vi3G7iY867.jpg","topictype":"精","views":683098,"postmemberid":0,"imgurl":"","bbsid":3589,"bbstype":"c","bbsname":"媳妇当车模784季"},{"topicid":55176260,"title":"一份夏天的礼物 媳妇携手长安CS75","lastreplydate":"16小时前","postusername":"一起去迷路","replycounts":613,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M04/DA/AD/userphotos/2016/08/13/17/240180_wKjBwVeu7IqAE_htAAE7Y8RwbVM363.jpg","topictype":"精","views":804269,"postmemberid":0,"imgurl":"","bbsid":3204,"bbstype":"c","bbsname":"媳妇当车模783季"},{"topicid":48095432,"title":"惹火又不失清纯 媳妇助阵宝马320Li","lastreplydate":"1小时前","postusername":"宾利男","replycounts":3668,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0A/F1/83/userphotos/2016/08/08/09/240180_wKgH2len4wiAVaifAAEryLgvgw8093.jpg","topictype":"精","views":2095402,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"媳妇当车模782季"},{"topicid":54928861,"title":"这是我的菜 端庄媳妇与爱车共出镜","lastreplydate":"8小时前","postusername":"你来咬我呀i","replycounts":645,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M11/EE/04/userphotos/2016/08/05/13/240180_wKgH5lekJk-AO3cHAAE8zKHl2MA252.jpg","topictype":"精","views":690007,"postmemberid":0,"imgurl":"","bbsid":110,"bbstype":"c","bbsname":"媳妇当车模781季"},{"topicid":55117430,"title":"双喜临门 清纯媳妇携手昂科拉1.4T","lastreplydate":"9分钟前","postusername":"zhu2633256","replycounts":1653,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0E/FD/E1/userphotos/2016/08/16/14/240180_wKjB01eyuVmAI7yCAAEg_MgYO2s586.jpg","topictype":"精","views":888338,"postmemberid":0,"imgurl":"","bbsid":2896,"bbstype":"c","bbsname":"媳妇当车模780季"},{"topicid":54903802,"title":"最美丽的你 媳妇与凯迪拉克ATS-L","lastreplydate":"4分钟前","postusername":"王贤是我小公主","replycounts":2023,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M12/ED/3C/userphotos/2016/08/05/10/240180_wKgH6Fej9VGAI1rsAAJTUH-wHxQ547.jpg","topictype":"精","views":1304233,"postmemberid":0,"imgurl":"","bbsid":3207,"bbstype":"c","bbsname":"媳妇当车模779季"},{"topicid":55437003,"title":"遇见不一样的自己 车主出镜当车模","lastreplydate":"7分钟前","postusername":"jingjing8993","replycounts":2000,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M02/41/92/userphotos/2016/09/14/17/240180_wKgHzFfZF6-AQv03AAE7jiI0MWg169.jpg","topictype":"精","views":2016151,"postmemberid":0,"imgurl":"","bbsid":2678,"bbstype":"c","bbsname":"媳妇当车模778季"},{"topicid":54637177,"title":"天使脸蛋魔鬼身材 媳妇与宝马320i","lastreplydate":"3分钟前","postusername":"Love丿Slave","replycounts":4889,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0D/33/12/userphotos/2016/09/21/22/240180_wKgFW1filA2AZYJ5AASRQIbzeeQ570.jpg","topictype":"精","views":2385760,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"媳妇当车模777季"},{"topicid":55030013,"title":"心酸提车历程 美人与我的经典老车","lastreplydate":"7小时前","postusername":"只倾雨你","replycounts":840,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M15/F6/AC/userphotos/2016/08/11/15/240180_wKjBzFesKZCAM8bPAAF1SHrEAD8801.jpg","topictype":"精","views":938478,"postmemberid":0,"imgurl":"","bbsid":100006,"bbstype":"a","bbsname":"媳妇当车模776季"},{"topicid":55144735,"title":"心情十分激动 奔驰G500与我的媳妇","lastreplydate":"3小时前","postusername":"琢琢黍栗","replycounts":2261,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M0E/4F/4A/userphotos/2016/09/21/22/240180_wKgH1FfilCOAJppZAAKt4Va77oA006.jpg","topictype":"精","views":1554247,"postmemberid":0,"imgurl":"","bbsid":60,"bbstype":"c","bbsname":"媳妇当车模775季"},{"topicid":54734253,"title":"专属赤木晴子 元气媳妇与缤智1.8L","lastreplydate":"42分钟前","postusername":"机智的Tyrion","replycounts":2368,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M15/CA/32/userphotos/2016/08/02/19/240180_wKgFVleghX-ATNMIAAErAzXIQj8469.jpg","topictype":"精","views":1562189,"postmemberid":0,"imgurl":"","bbsid":3460,"bbstype":"c","bbsname":"媳妇当车模774季"},{"topicid":54581605,"title":"夏日专属记忆 清纯媳妇携手高尔夫","lastreplydate":"2小时前","postusername":"小乐1993","replycounts":2578,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M14/DC/12/userphotos/2016/07/25/17/240180_wKjByVeV4JuAbFmxAAEyeEzbCyI594.jpg","topictype":"精","views":1308326,"postmemberid":0,"imgurl":"","bbsid":871,"bbstype":"c","bbsname":"媳妇当车模773季"},{"topicid":54387543,"title":"永远的女神 长腿媳妇助阵威朗20T","lastreplydate":"41分钟前","postusername":"安欣1","replycounts":2437,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M0C/D5/38/userphotos/2016/07/19/14/240180_wKgHzFeNyKGAAGmqAAEZA1YYGa4130.jpg","topictype":"精","views":1767432,"postmemberid":0,"imgurl":"","bbsid":3751,"bbstype":"c","bbsname":"媳妇当车模772季"},{"topicid":54809439,"title":"文艺还是俏皮 媳妇助阵森林人出镜","lastreplydate":"2小时前","postusername":"游历着","replycounts":1245,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M0B/C7/2C/userphotos/2016/08/01/10/240180_wKgFV1eetLSAVNCtAAE7hdA3EG8167.jpg","topictype":"精","views":810578,"postmemberid":0,"imgurl":"","bbsid":285,"bbstype":"c","bbsname":"媳妇当车模771季"},{"topicid":55148520,"title":"实现久违的愿望 媳妇与车火辣写真","lastreplydate":"41分钟前","postusername":"AQUA水叮当","replycounts":5941,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g12/M0A/52/89/userphotos/2016/09/21/22/240180_wKjBy1fil5eAS8axAAOz-bTjuss551.jpg","topictype":"精","views":2409200,"postmemberid":0,"imgurl":"","bbsid":2137,"bbstype":"c","bbsname":"媳妇当车模770季"},{"topicid":54209063,"title":"最长情的告白 携手雷凌演绎视觉秀","lastreplydate":"40分钟前","postusername":"ZH勇敢的心","replycounts":1941,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g12/M03/CE/29/userphotos/2016/07/12/16/240180_wKjBy1eErt-AfvsUAAE-Z-TnZNM299.jpg","topictype":"精","views":967402,"postmemberid":0,"imgurl":"","bbsid":3462,"bbstype":"c","bbsname":"媳妇当车模769季"},{"topicid":54165915,"title":"多年的梦想以实现 我的老婆与博越","lastreplydate":"40分钟前","postusername":"刘哥哥039","replycounts":2924,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M01/CB/1A/userphotos/2016/07/11/17/240180_wKgH2VeDZO-AOZ6FAAGJ4kfWkx8779.jpg","topictype":"精","views":1621755,"postmemberid":0,"imgurl":"","bbsid":3788,"bbstype":"c","bbsname":"媳妇当车模768季"},{"topicid":54464042,"title":"你是我的一首歌 媳妇与马自达CX-4","lastreplydate":"1小时前","postusername":"村口抢稀饭","replycounts":3414,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M0B/D8/5F/userphotos/2016/07/21/14/240180_wKgH0leQbAKAZEc-AAGOg-DwD_s345.jpg","topictype":"精","views":1660193,"postmemberid":0,"imgurl":"","bbsid":3968,"bbstype":"c","bbsname":"媳妇当车模767季"},{"topicid":54349632,"title":"看灵动的舞鞋 舞蹈精灵与悦翔V7 ","lastreplydate":"3小时前","postusername":"EminemFans","replycounts":2184,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M0E/CC/B8/userphotos/2016/07/17/12/240180_wKjBxleLBd-AUFnsAAEw8KYg9rw805.jpg","topictype":"精","views":659700,"postmemberid":0,"imgurl":"","bbsid":3422,"bbstype":"c","bbsname":"媳妇当车模766季"},{"topicid":53512149,"title":"可信任的伙伴 元气媳妇携雅阁出镜","lastreplydate":"9小时前","postusername":"昱興","replycounts":982,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M15/8F/4B/userphotos/2016/06/20/16/240180_wKgFW1dnrX-ASapvAAFCxmBBKGE010.jpg","topictype":"精","views":853985,"postmemberid":0,"imgurl":"","bbsid":78,"bbstype":"c","bbsname":"媳妇当车模765季"},{"topicid":54844874,"title":"感受青春气息 老婆\u201c野战\u201d哈弗H6","lastreplydate":"4小时前","postusername":"金盾018445","replycounts":2419,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M12/E9/DB/userphotos/2016/08/02/17/240180_wKgH1legYtWAS2piAAE66-Gr_EQ853.jpg","topictype":"精","views":1792448,"postmemberid":0,"imgurl":"","bbsid":2123,"bbstype":"c","bbsname":"媳妇当车模764季"},{"topicid":53879422,"title":"烈日炎炎的六月 美丽媳妇携手英朗","lastreplydate":"6小时前","postusername":"爱车的人5211","replycounts":1439,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M15/BB/B7/userphotos/2016/07/01/10/240180_wKjByFd12iiAZvgbAAFT6tXxTs0537.jpg","topictype":"精","views":1171829,"postmemberid":0,"imgurl":"","bbsid":982,"bbstype":"c","bbsname":"媳妇当车模763季"},{"topicid":53411315,"title":"四年的爱情长跑 媳妇鼎立助阵迈腾","lastreplydate":"3天前","postusername":"xhgnokia2012","replycounts":1166,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M04/A7/5B/userphotos/2016/06/15/14/240180_wKgHzFdg-aaAXHwIAAFjqHIUhRo252.jpg","topictype":"精","views":1286774,"postmemberid":0,"imgurl":"","bbsid":496,"bbstype":"c","bbsname":"媳妇当车模762季"}]}
     */

    private String message;
    private int returncode;
    /**
     * pageindex : 1
     * pagecount : 27
     * rowcount : 791
     * list : [{"topicid":56254930,"title":"幸福因为有你 媳妇与爱车的机场秀","lastreplydate":"1分钟前","postusername":"大改变成就超超","replycounts":55,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M00/52/BA/userphotos/2016/09/21/21/240180_wKgH3VfiixmAacavAAI4Tih4rEw840.jpg","topictype":"精","views":17941,"postmemberid":0,"imgurl":"","bbsid":200226,"bbstype":"o","bbsname":"媳妇当车模791季"},{"topicid":55749571,"title":"一路走来有苦有乐 辣妈出镜当车模","lastreplydate":"4分钟前","postusername":"86866449我","replycounts":2260,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M06/52/76/userphotos/2016/09/21/21/240180_wKjByFfii4qAVX7yAAMkwCkI0cA994.jpg","topictype":"精","views":521216,"postmemberid":0,"imgurl":"","bbsid":2228,"bbstype":"c","bbsname":"媳妇当车模790季"},{"topicid":55837020,"title":"清新抑或是妩媚 娇俏女友百变出场","lastreplydate":"10分钟前","postusername":"alex_cool9","replycounts":1967,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M0C/32/CA/userphotos/2016/09/21/21/240180_wKjBwFfijieAPJH4AALa-IGqp8w133.jpg","topictype":"精","views":664558,"postmemberid":0,"imgurl":"","bbsid":3043,"bbstype":"c","bbsname":"媳妇当车模789季"},{"topicid":55106505,"title":"做个有福之人 俏丽媳妇携爱车出镜","lastreplydate":"14分钟前","postusername":"xujinle","replycounts":697,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M01/50/3E/userphotos/2016/09/21/21/240180_wKjByVfijrCADpZvAAMMKDQlkeA087.jpg","topictype":"精","views":556332,"postmemberid":0,"imgurl":"","bbsid":117,"bbstype":"c","bbsname":"媳妇当车模788季"},{"topicid":55759139,"title":"多口之家之选 气质媳妇助阵华颂7","lastreplydate":"44分钟前","postusername":"沈阳_大海","replycounts":554,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M0B/51/CE/userphotos/2016/09/21/21/240180_wKgH6FfijwKAXLT6AAXH-rBGH7U181.jpg","topictype":"精","views":553697,"postmemberid":0,"imgurl":"","bbsid":3607,"bbstype":"c","bbsname":"媳妇当车模787季"},{"topicid":55049520,"title":"两年始终相伴 俏美媳妇与爱车出境","lastreplydate":"2分钟前","postusername":"Colin_Joe","replycounts":1163,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M0D/D5/2C/userphotos/2016/08/09/08/240180_wKgFVFepI1GAfBWyAAFElUxmSnw437.jpg","topictype":"精","views":1003936,"postmemberid":0,"imgurl":"","bbsid":905,"bbstype":"c","bbsname":"媳妇当车模786季"},{"topicid":55118940,"title":"省油是关键 纯情软妹助阵雷凌双擎","lastreplydate":"9小时前","postusername":"提车电闪雷鸣","replycounts":815,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M07/F7/09/userphotos/2016/08/16/16/240180_wKjBz1eyzGKAOZGrAAFF_uEsM3Q740.jpg","topictype":"精","views":868809,"postmemberid":0,"imgurl":"","bbsid":3462,"bbstype":"c","bbsname":"媳妇当车模785季"},{"topicid":55116147,"title":"博瑞的深情 抵不住\u201c女王\u201d的姿态","lastreplydate":"10分钟前","postusername":"Hesir516","replycounts":841,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g21/M0A/D7/7C/userphotos/2016/08/11/14/240180_wKgFVVesGmOAdIBZAAE6Vi3G7iY867.jpg","topictype":"精","views":683098,"postmemberid":0,"imgurl":"","bbsid":3589,"bbstype":"c","bbsname":"媳妇当车模784季"},{"topicid":55176260,"title":"一份夏天的礼物 媳妇携手长安CS75","lastreplydate":"16小时前","postusername":"一起去迷路","replycounts":613,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M04/DA/AD/userphotos/2016/08/13/17/240180_wKjBwVeu7IqAE_htAAE7Y8RwbVM363.jpg","topictype":"精","views":804269,"postmemberid":0,"imgurl":"","bbsid":3204,"bbstype":"c","bbsname":"媳妇当车模783季"},{"topicid":48095432,"title":"惹火又不失清纯 媳妇助阵宝马320Li","lastreplydate":"1小时前","postusername":"宾利男","replycounts":3668,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0A/F1/83/userphotos/2016/08/08/09/240180_wKgH2len4wiAVaifAAEryLgvgw8093.jpg","topictype":"精","views":2095402,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"媳妇当车模782季"},{"topicid":54928861,"title":"这是我的菜 端庄媳妇与爱车共出镜","lastreplydate":"8小时前","postusername":"你来咬我呀i","replycounts":645,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M11/EE/04/userphotos/2016/08/05/13/240180_wKgH5lekJk-AO3cHAAE8zKHl2MA252.jpg","topictype":"精","views":690007,"postmemberid":0,"imgurl":"","bbsid":110,"bbstype":"c","bbsname":"媳妇当车模781季"},{"topicid":55117430,"title":"双喜临门 清纯媳妇携手昂科拉1.4T","lastreplydate":"9分钟前","postusername":"zhu2633256","replycounts":1653,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0E/FD/E1/userphotos/2016/08/16/14/240180_wKjB01eyuVmAI7yCAAEg_MgYO2s586.jpg","topictype":"精","views":888338,"postmemberid":0,"imgurl":"","bbsid":2896,"bbstype":"c","bbsname":"媳妇当车模780季"},{"topicid":54903802,"title":"最美丽的你 媳妇与凯迪拉克ATS-L","lastreplydate":"4分钟前","postusername":"王贤是我小公主","replycounts":2023,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M12/ED/3C/userphotos/2016/08/05/10/240180_wKgH6Fej9VGAI1rsAAJTUH-wHxQ547.jpg","topictype":"精","views":1304233,"postmemberid":0,"imgurl":"","bbsid":3207,"bbstype":"c","bbsname":"媳妇当车模779季"},{"topicid":55437003,"title":"遇见不一样的自己 车主出镜当车模","lastreplydate":"7分钟前","postusername":"jingjing8993","replycounts":2000,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M02/41/92/userphotos/2016/09/14/17/240180_wKgHzFfZF6-AQv03AAE7jiI0MWg169.jpg","topictype":"精","views":2016151,"postmemberid":0,"imgurl":"","bbsid":2678,"bbstype":"c","bbsname":"媳妇当车模778季"},{"topicid":54637177,"title":"天使脸蛋魔鬼身材 媳妇与宝马320i","lastreplydate":"3分钟前","postusername":"Love丿Slave","replycounts":4889,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0D/33/12/userphotos/2016/09/21/22/240180_wKgFW1filA2AZYJ5AASRQIbzeeQ570.jpg","topictype":"精","views":2385760,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"媳妇当车模777季"},{"topicid":55030013,"title":"心酸提车历程 美人与我的经典老车","lastreplydate":"7小时前","postusername":"只倾雨你","replycounts":840,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M15/F6/AC/userphotos/2016/08/11/15/240180_wKjBzFesKZCAM8bPAAF1SHrEAD8801.jpg","topictype":"精","views":938478,"postmemberid":0,"imgurl":"","bbsid":100006,"bbstype":"a","bbsname":"媳妇当车模776季"},{"topicid":55144735,"title":"心情十分激动 奔驰G500与我的媳妇","lastreplydate":"3小时前","postusername":"琢琢黍栗","replycounts":2261,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M0E/4F/4A/userphotos/2016/09/21/22/240180_wKgH1FfilCOAJppZAAKt4Va77oA006.jpg","topictype":"精","views":1554247,"postmemberid":0,"imgurl":"","bbsid":60,"bbstype":"c","bbsname":"媳妇当车模775季"},{"topicid":54734253,"title":"专属赤木晴子 元气媳妇与缤智1.8L","lastreplydate":"42分钟前","postusername":"机智的Tyrion","replycounts":2368,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M15/CA/32/userphotos/2016/08/02/19/240180_wKgFVleghX-ATNMIAAErAzXIQj8469.jpg","topictype":"精","views":1562189,"postmemberid":0,"imgurl":"","bbsid":3460,"bbstype":"c","bbsname":"媳妇当车模774季"},{"topicid":54581605,"title":"夏日专属记忆 清纯媳妇携手高尔夫","lastreplydate":"2小时前","postusername":"小乐1993","replycounts":2578,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M14/DC/12/userphotos/2016/07/25/17/240180_wKjByVeV4JuAbFmxAAEyeEzbCyI594.jpg","topictype":"精","views":1308326,"postmemberid":0,"imgurl":"","bbsid":871,"bbstype":"c","bbsname":"媳妇当车模773季"},{"topicid":54387543,"title":"永远的女神 长腿媳妇助阵威朗20T","lastreplydate":"41分钟前","postusername":"安欣1","replycounts":2437,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M0C/D5/38/userphotos/2016/07/19/14/240180_wKgHzFeNyKGAAGmqAAEZA1YYGa4130.jpg","topictype":"精","views":1767432,"postmemberid":0,"imgurl":"","bbsid":3751,"bbstype":"c","bbsname":"媳妇当车模772季"},{"topicid":54809439,"title":"文艺还是俏皮 媳妇助阵森林人出镜","lastreplydate":"2小时前","postusername":"游历着","replycounts":1245,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M0B/C7/2C/userphotos/2016/08/01/10/240180_wKgFV1eetLSAVNCtAAE7hdA3EG8167.jpg","topictype":"精","views":810578,"postmemberid":0,"imgurl":"","bbsid":285,"bbstype":"c","bbsname":"媳妇当车模771季"},{"topicid":55148520,"title":"实现久违的愿望 媳妇与车火辣写真","lastreplydate":"41分钟前","postusername":"AQUA水叮当","replycounts":5941,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g12/M0A/52/89/userphotos/2016/09/21/22/240180_wKjBy1fil5eAS8axAAOz-bTjuss551.jpg","topictype":"精","views":2409200,"postmemberid":0,"imgurl":"","bbsid":2137,"bbstype":"c","bbsname":"媳妇当车模770季"},{"topicid":54209063,"title":"最长情的告白 携手雷凌演绎视觉秀","lastreplydate":"40分钟前","postusername":"ZH勇敢的心","replycounts":1941,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g12/M03/CE/29/userphotos/2016/07/12/16/240180_wKjBy1eErt-AfvsUAAE-Z-TnZNM299.jpg","topictype":"精","views":967402,"postmemberid":0,"imgurl":"","bbsid":3462,"bbstype":"c","bbsname":"媳妇当车模769季"},{"topicid":54165915,"title":"多年的梦想以实现 我的老婆与博越","lastreplydate":"40分钟前","postusername":"刘哥哥039","replycounts":2924,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M01/CB/1A/userphotos/2016/07/11/17/240180_wKgH2VeDZO-AOZ6FAAGJ4kfWkx8779.jpg","topictype":"精","views":1621755,"postmemberid":0,"imgurl":"","bbsid":3788,"bbstype":"c","bbsname":"媳妇当车模768季"},{"topicid":54464042,"title":"你是我的一首歌 媳妇与马自达CX-4","lastreplydate":"1小时前","postusername":"村口抢稀饭","replycounts":3414,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M0B/D8/5F/userphotos/2016/07/21/14/240180_wKgH0leQbAKAZEc-AAGOg-DwD_s345.jpg","topictype":"精","views":1660193,"postmemberid":0,"imgurl":"","bbsid":3968,"bbstype":"c","bbsname":"媳妇当车模767季"},{"topicid":54349632,"title":"看灵动的舞鞋 舞蹈精灵与悦翔V7 ","lastreplydate":"3小时前","postusername":"EminemFans","replycounts":2184,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M0E/CC/B8/userphotos/2016/07/17/12/240180_wKjBxleLBd-AUFnsAAEw8KYg9rw805.jpg","topictype":"精","views":659700,"postmemberid":0,"imgurl":"","bbsid":3422,"bbstype":"c","bbsname":"媳妇当车模766季"},{"topicid":53512149,"title":"可信任的伙伴 元气媳妇携雅阁出镜","lastreplydate":"9小时前","postusername":"昱興","replycounts":982,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M15/8F/4B/userphotos/2016/06/20/16/240180_wKgFW1dnrX-ASapvAAFCxmBBKGE010.jpg","topictype":"精","views":853985,"postmemberid":0,"imgurl":"","bbsid":78,"bbstype":"c","bbsname":"媳妇当车模765季"},{"topicid":54844874,"title":"感受青春气息 老婆\u201c野战\u201d哈弗H6","lastreplydate":"4小时前","postusername":"金盾018445","replycounts":2419,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M12/E9/DB/userphotos/2016/08/02/17/240180_wKgH1legYtWAS2piAAE66-Gr_EQ853.jpg","topictype":"精","views":1792448,"postmemberid":0,"imgurl":"","bbsid":2123,"bbstype":"c","bbsname":"媳妇当车模764季"},{"topicid":53879422,"title":"烈日炎炎的六月 美丽媳妇携手英朗","lastreplydate":"6小时前","postusername":"爱车的人5211","replycounts":1439,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M15/BB/B7/userphotos/2016/07/01/10/240180_wKjByFd12iiAZvgbAAFT6tXxTs0537.jpg","topictype":"精","views":1171829,"postmemberid":0,"imgurl":"","bbsid":982,"bbstype":"c","bbsname":"媳妇当车模763季"},{"topicid":53411315,"title":"四年的爱情长跑 媳妇鼎立助阵迈腾","lastreplydate":"3天前","postusername":"xhgnokia2012","replycounts":1166,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M04/A7/5B/userphotos/2016/06/15/14/240180_wKgHzFdg-aaAXHwIAAFjqHIUhRo252.jpg","topictype":"精","views":1286774,"postmemberid":0,"imgurl":"","bbsid":496,"bbstype":"c","bbsname":"媳妇当车模762季"}]
     */

    private ResultBean result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int pageindex;
        private int pagecount;
        private int rowcount;
        /**
         * topicid : 56254930
         * title : 幸福因为有你 媳妇与爱车的机场秀
         * lastreplydate : 1分钟前
         * postusername : 大改变成就超超
         * replycounts : 55
         * isclosed : 0
         * bigpic :
         * smallpic : http://club2.autoimg.cn/album/g7/M00/52/BA/userphotos/2016/09/21/21/240180_wKgH3VfiixmAacavAAI4Tih4rEw840.jpg
         * topictype : 精
         * views : 17941
         * postmemberid : 0
         * imgurl :
         * bbsid : 200226
         * bbstype : o
         * bbsname : 媳妇当车模791季
         */

        private List<ListBean> list;

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private int replycounts;
            private int isclosed;
            private String bigpic;
            private String smallpic;
            private String topictype;
            private int views;
            private int postmemberid;
            private String imgurl;
            private int bbsid;
            private String bbstype;
            private String bbsname;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public int getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(int replycounts) {
                this.replycounts = replycounts;
            }

            public int getIsclosed() {
                return isclosed;
            }

            public void setIsclosed(int isclosed) {
                this.isclosed = isclosed;
            }

            public String getBigpic() {
                return bigpic;
            }

            public void setBigpic(String bigpic) {
                this.bigpic = bigpic;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public String getTopictype() {
                return topictype;
            }

            public void setTopictype(String topictype) {
                this.topictype = topictype;
            }

            public int getViews() {
                return views;
            }

            public void setViews(int views) {
                this.views = views;
            }

            public int getPostmemberid() {
                return postmemberid;
            }

            public void setPostmemberid(int postmemberid) {
                this.postmemberid = postmemberid;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbstype() {
                return bbstype;
            }

            public void setBbstype(String bbstype) {
                this.bbstype = bbstype;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }
        }
    }
}
