package com.example.dllo.forum.forums;

import com.example.dllo.carhome.BaseFragment;
import com.example.dllo.carhome.R;

/**
 * Created by dllo on 16/9/20.
 */
public class ForumsFragment extends BaseFragment {


    @Override
    protected int setLayout() {
        return R.layout.forums_fragment;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
