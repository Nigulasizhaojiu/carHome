package com.example.dllo.recommend.other;

import java.util.List;

/**
 * Created by dllo on 16/10/8.
 */
public class OtherBean {
    /**
     * rowcount : 34643
     * isloadmore : true
     * headlineinfo : {}
     * focusimg : []
     * newslist : [{"dbid":0,"id":894002,"title":"您怎么看？北京网约车必须是京人京车","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 18:02:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/67/69/400x300_0_autohomecar__wKgHzlf4v_2AamhXAAGCSRZ-6oI085.jpg","replycount":408,"pagecount":1,"jumppage":1,"lasttime":"20161008180241894002","newstype":0,"updatetime":"20161008180353"},{"dbid":0,"id":894001,"title":"综合油耗2.4L/100km 红旗H7 PHEV新消息","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 17:42:52","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M05/6A/40/400x300_0_autohomecar__wKjByVf4s7eAf9PlAAGawYfMTGg071.jpg","replycount":231,"pagecount":1,"jumppage":1,"lasttime":"20161008174252894001","newstype":0,"updatetime":"20161008174238"},{"dbid":0,"id":894005,"title":"售9.68-11.88万 北汽威旺S50自动挡上市","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 17:40:45","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M0B/4B/AD/400x300_0_autohomecar__wKgFWlf4ueCAV9pYAAGs9pfWDIc536.jpg","replycount":127,"pagecount":1,"jumppage":1,"lasttime":"20161008174045894005","newstype":0,"updatetime":"20161008173917"},{"dbid":0,"id":894000,"title":"更聪明更精确 奔驰研发新LED大灯技术","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:58:36","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M00/4B/CD/400x300_0_autohomecar__wKjBwVf4sjOALfG5AAC87mV7GzU406.jpg","replycount":93,"pagecount":1,"jumppage":1,"lasttime":"20161008165836894000","newstype":0,"updatetime":"20161008165811"},{"dbid":0,"id":893996,"title":"或2017年3月亮相 曝全新奥迪A8假想图","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:51:39","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M0C/66/7D/400x300_0_autohomecar__wKgH1Vf4riWAO7dzAAHGY6h6KqE870.jpg","replycount":315,"pagecount":1,"jumppage":1,"lasttime":"20161008165139893996","newstype":0,"updatetime":"20161008165047"},{"dbid":0,"id":893992,"title":"外观设计更时尚 三菱全新ASX劲炫假想图","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:16:55","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M00/48/B0/400x300_0_autohomecar__wKgFVFf4qPCAbcDOAAGD7fuLxvo253.jpg","replycount":168,"pagecount":1,"jumppage":1,"lasttime":"20161008161655893992","newstype":0,"updatetime":"20161008161605"},{"dbid":0,"id":893991,"title":"采用新设计 帝豪百万纪念版或11月上市","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 15:49:24","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M12/6B/A0/400x300_0_autohomecar__wKjBx1f4o6iATT3wAAFeBrG6Poo706.jpg","replycount":200,"pagecount":1,"jumppage":1,"lasttime":"20161008154924893991","newstype":0,"updatetime":"20161008154612"},{"dbid":0,"id":893977,"title":"年底上市 东风风神AX5 10月9日下线 ","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 10:59:26","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M01/4A/60/400x300_0_autohomecar__wKjBw1f4WSmAQPMRAAFLOPfM_74696.jpg","replycount":208,"pagecount":1,"jumppage":1,"lasttime":"20161008105926893977","newstype":0,"updatetime":"20161008105715"},{"dbid":0,"id":893976,"title":"采用新品牌销售 曝更多大众电动车计划","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 10:14:14","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0D/6B/4B/400x300_0_autohomecar__wKgH41f4VZKATcE7AAE3892GX4M267.jpg","replycount":100,"pagecount":1,"jumppage":1,"lasttime":"20161008101414893976","newstype":0,"updatetime":"20161008164309"},{"dbid":0,"id":893975,"title":"共9款车型 众泰SR9将于10月12日下线","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 9:57:24","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M15/4A/E1/400x300_0_autohomecar__wKjBwVf4SdiAHaM8AAEy_L0cQ70698.jpg","replycount":1896,"pagecount":1,"jumppage":1,"lasttime":"20161008095724893975","newstype":0,"updatetime":"20161008095709"},{"dbid":0,"id":893974,"title":"或基于大众Amarok 斯柯达皮卡消息曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 9:55:40","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M07/4B/32/400x300_0_autohomecar__wKgFWFf4T-GAfVlkAAEMADiwQq0981.jpg","replycount":151,"pagecount":1,"jumppage":1,"lasttime":"20161008095540893974","newstype":0,"updatetime":"20161008094619"},{"dbid":0,"id":893967,"title":"Mustang Shelby GT350或配双离合变速箱","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M06/46/E7/400x300_0_autohomecar__wKgFVFf3QzyAM_qLAAEqLY302OQ982.jpg","replycount":227,"pagecount":1,"jumppage":1,"lasttime":"20161008060500893967","newstype":0,"updatetime":"20161007152709"},{"dbid":0,"id":893966,"title":"或达609马力 宝马M8新信息及假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0C/65/C3/400x300_0_autohomecar__wKgH0lf3OIqAesV1AADTyETBot4234.jpg","replycount":380,"pagecount":1,"jumppage":1,"lasttime":"20161008060500893966","newstype":0,"updatetime":"20161007215041"},{"dbid":0,"id":893971,"title":"2017年推出 新一代欧宝Corsa谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M08/6D/53/400x300_0_autohomecar__wKgH3lf3mv-ARUWpAAGEU1zmcj0091.jpg","replycount":48,"pagecount":1,"jumppage":1,"lasttime":"20161008060100893971","newstype":0,"updatetime":"20161007205430"},{"dbid":0,"id":893968,"title":"11月试营 雷诺自动驾驶示范区落户武汉","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M07/6A/39/400x300_0_autohomecar__wKgH4Ff3YxqACJe-AAFqAImLz-o039.jpg","replycount":57,"pagecount":1,"jumppage":1,"lasttime":"20161008060000893968","newstype":0,"updatetime":"20161008090247"},{"dbid":0,"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/400x300_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":358,"pagecount":3,"jumppage":1,"lasttime":"20161008000000893970","newstype":0,"updatetime":"20161008094801"},{"dbid":0,"id":893965,"title":"或售6.39-7.99万 瑞虎3X疑似售价曝光","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M02/49/FB/400x300_0_autohomecar__wKgFWFf3NM-AcTbUAAF3g2FF8Mk597.jpg","replycount":929,"pagecount":1,"jumppage":1,"lasttime":"20161007200500893965","newstype":0,"updatetime":"20161007140356"},{"dbid":0,"id":893963,"title":"性能再提升？疑似AMG C 63 R Coupe谍照","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M00/65/1A/400x300_0_autohomecar__wKgH51f3F9uAab2iAAGUCfK3BtA674.jpg","replycount":316,"pagecount":1,"jumppage":1,"lasttime":"20161007200500893963","newstype":0,"updatetime":"20161007123301"},{"dbid":0,"id":893969,"title":"家用车新选择 北京现代悦纳实车到店","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 18:02:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M13/67/48/400x300_0_autohomecar__wKgH1lf3WzOAWePkAAHJ3vYX9zM583.jpg","replycount":637,"pagecount":1,"jumppage":1,"lasttime":"20161007180200893969","newstype":0,"updatetime":"20161008094639"},{"dbid":0,"id":893962,"title":"或命名Atlas 大众新SUV海外版更多信息","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 11:03:06","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/69/0F/400x300_0_autohomecar__wKjB0Ff3D4SAXJRfAAG2HanTlZI879.jpg","replycount":767,"pagecount":1,"jumppage":1,"lasttime":"20161007110306893962","newstype":0,"updatetime":"20161007110225"},{"dbid":0,"id":893961,"title":"外观内饰更时尚 曝帝豪百万纪念版实车","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 10:15:20","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/65/05/400x300_0_autohomecar__wKgH11f2-ziAQ6ERAAF7I-mg0ME404.jpg","replycount":928,"pagecount":1,"jumppage":1,"lasttime":"20161007101520893961","newstype":0,"updatetime":"20161007101422"},{"dbid":0,"id":893959,"title":"延续XC90设计 曝新沃尔沃XC60内饰谍照","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g12/M0F/62/A9/400x300_0_autohomecar__wKgH01f2A42ABEqKAAGcHwP7Q1U293.jpg","replycount":836,"pagecount":1,"jumppage":1,"lasttime":"20161007060100893959","newstype":0,"updatetime":"20161006155611"},{"dbid":0,"id":893958,"title":"造型更战斗 兰博基尼新款Aventador谍照","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M09/45/39/400x300_0_autohomecar__wKgFV1f18TqAPmlEAAG8pCPuvM8328.jpg","replycount":495,"pagecount":1,"jumppage":1,"lasttime":"20161006200500893958","newstype":0,"updatetime":"20161006145353"},{"dbid":0,"id":893957,"title":"限时限量发售 斯巴鲁WRX S4 tS官图发布","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 20:02:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M0C/48/22/400x300_0_autohomecar__wKjBwVf148WALHY3AAEM1DqrqPY203.jpg","replycount":343,"pagecount":1,"jumppage":1,"lasttime":"20161006200200893957","newstype":0,"updatetime":"20161007082710"},{"dbid":0,"id":893956,"title":"或定名哈弗H4S 哈弗全新SUV谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 10:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M04/47/E4/400x300_0_autohomecar__wKjBwVf1s76AdXldAAE86WrKVPw534.jpg","replycount":1556,"pagecount":1,"jumppage":1,"lasttime":"20161006101941893956","newstype":0,"updatetime":"20161006101719"},{"dbid":0,"id":893955,"title":"或采用对开门设计 曝疑似宝马i5专利图","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 9:14:32","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M06/46/B0/400x300_0_autohomecar__wKjBwlf1pGGAE5DqAACG5VLPJSA320.jpg","replycount":320,"pagecount":1,"jumppage":1,"lasttime":"20161006091432893955","newstype":0,"updatetime":"20161006092205"},{"dbid":0,"id":893952,"title":"或搭载1.6T发动机 玛驰NISMO假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M11/66/3C/400x300_0_autohomecar__wKgH4Vf0ZBSAISwUAAF77q1eNrY075.jpg","replycount":458,"pagecount":1,"jumppage":1,"lasttime":"20161006060000893952","newstype":0,"updatetime":"20161005163601"},{"dbid":0,"id":893951,"title":"对手锁定A3 宝马1系三厢版2017年初上市","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M00/43/F7/400x300_0_autohomecar__wKgFVlf0WzWAQgSpAADM79it6ss651.jpg","replycount":1359,"pagecount":1,"jumppage":1,"lasttime":"20161005200500893951","newstype":0,"updatetime":"20161005094652"},{"dbid":0,"id":893953,"title":"四驱入门预售30万 曝冠道上市车型信息","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/47/E4/400x300_0_autohomecar__wKgFW1f0uqCAPq7MAAGDlcV_LyM581.jpg","replycount":2779,"pagecount":1,"jumppage":1,"lasttime":"20161005200000893953","newstype":0,"updatetime":"20161005163534"},{"dbid":0,"id":893950,"title":"2017年上市 曝大众Tiguan长轴距版谍照","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 9:23:54","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0A/62/56/400x300_0_autohomecar__wKgH11f0VdaATpFiAAFu2zWSHJE970.jpg","replycount":1242,"pagecount":1,"jumppage":1,"lasttime":"20161005092354893950","newstype":0,"updatetime":"20161005092346"}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":34643,"isloadmore":true,"headlineinfo":{},"focusimg":[],"newslist":[{"dbid":0,"id":894002,"title":"您怎么看？北京网约车必须是京人京车","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 18:02:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/67/69/400x300_0_autohomecar__wKgHzlf4v_2AamhXAAGCSRZ-6oI085.jpg","replycount":408,"pagecount":1,"jumppage":1,"lasttime":"20161008180241894002","newstype":0,"updatetime":"20161008180353"},{"dbid":0,"id":894001,"title":"综合油耗2.4L/100km 红旗H7 PHEV新消息","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 17:42:52","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M05/6A/40/400x300_0_autohomecar__wKjByVf4s7eAf9PlAAGawYfMTGg071.jpg","replycount":231,"pagecount":1,"jumppage":1,"lasttime":"20161008174252894001","newstype":0,"updatetime":"20161008174238"},{"dbid":0,"id":894005,"title":"售9.68-11.88万 北汽威旺S50自动挡上市","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 17:40:45","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M0B/4B/AD/400x300_0_autohomecar__wKgFWlf4ueCAV9pYAAGs9pfWDIc536.jpg","replycount":127,"pagecount":1,"jumppage":1,"lasttime":"20161008174045894005","newstype":0,"updatetime":"20161008173917"},{"dbid":0,"id":894000,"title":"更聪明更精确 奔驰研发新LED大灯技术","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:58:36","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M00/4B/CD/400x300_0_autohomecar__wKjBwVf4sjOALfG5AAC87mV7GzU406.jpg","replycount":93,"pagecount":1,"jumppage":1,"lasttime":"20161008165836894000","newstype":0,"updatetime":"20161008165811"},{"dbid":0,"id":893996,"title":"或2017年3月亮相 曝全新奥迪A8假想图","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:51:39","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M0C/66/7D/400x300_0_autohomecar__wKgH1Vf4riWAO7dzAAHGY6h6KqE870.jpg","replycount":315,"pagecount":1,"jumppage":1,"lasttime":"20161008165139893996","newstype":0,"updatetime":"20161008165047"},{"dbid":0,"id":893992,"title":"外观设计更时尚 三菱全新ASX劲炫假想图","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 16:16:55","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M00/48/B0/400x300_0_autohomecar__wKgFVFf4qPCAbcDOAAGD7fuLxvo253.jpg","replycount":168,"pagecount":1,"jumppage":1,"lasttime":"20161008161655893992","newstype":0,"updatetime":"20161008161605"},{"dbid":0,"id":893991,"title":"采用新设计 帝豪百万纪念版或11月上市","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 15:49:24","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M12/6B/A0/400x300_0_autohomecar__wKjBx1f4o6iATT3wAAFeBrG6Poo706.jpg","replycount":200,"pagecount":1,"jumppage":1,"lasttime":"20161008154924893991","newstype":0,"updatetime":"20161008154612"},{"dbid":0,"id":893977,"title":"年底上市 东风风神AX5 10月9日下线 ","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 10:59:26","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M01/4A/60/400x300_0_autohomecar__wKjBw1f4WSmAQPMRAAFLOPfM_74696.jpg","replycount":208,"pagecount":1,"jumppage":1,"lasttime":"20161008105926893977","newstype":0,"updatetime":"20161008105715"},{"dbid":0,"id":893976,"title":"采用新品牌销售 曝更多大众电动车计划","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 10:14:14","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0D/6B/4B/400x300_0_autohomecar__wKgH41f4VZKATcE7AAE3892GX4M267.jpg","replycount":100,"pagecount":1,"jumppage":1,"lasttime":"20161008101414893976","newstype":0,"updatetime":"20161008164309"},{"dbid":0,"id":893975,"title":"共9款车型 众泰SR9将于10月12日下线","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 9:57:24","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M15/4A/E1/400x300_0_autohomecar__wKjBwVf4SdiAHaM8AAEy_L0cQ70698.jpg","replycount":1896,"pagecount":1,"jumppage":1,"lasttime":"20161008095724893975","newstype":0,"updatetime":"20161008095709"},{"dbid":0,"id":893974,"title":"或基于大众Amarok 斯柯达皮卡消息曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 9:55:40","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M07/4B/32/400x300_0_autohomecar__wKgFWFf4T-GAfVlkAAEMADiwQq0981.jpg","replycount":151,"pagecount":1,"jumppage":1,"lasttime":"20161008095540893974","newstype":0,"updatetime":"20161008094619"},{"dbid":0,"id":893967,"title":"Mustang Shelby GT350或配双离合变速箱","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M06/46/E7/400x300_0_autohomecar__wKgFVFf3QzyAM_qLAAEqLY302OQ982.jpg","replycount":227,"pagecount":1,"jumppage":1,"lasttime":"20161008060500893967","newstype":0,"updatetime":"20161007152709"},{"dbid":0,"id":893966,"title":"或达609马力 宝马M8新信息及假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0C/65/C3/400x300_0_autohomecar__wKgH0lf3OIqAesV1AADTyETBot4234.jpg","replycount":380,"pagecount":1,"jumppage":1,"lasttime":"20161008060500893966","newstype":0,"updatetime":"20161007215041"},{"dbid":0,"id":893971,"title":"2017年推出 新一代欧宝Corsa谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M08/6D/53/400x300_0_autohomecar__wKgH3lf3mv-ARUWpAAGEU1zmcj0091.jpg","replycount":48,"pagecount":1,"jumppage":1,"lasttime":"20161008060100893971","newstype":0,"updatetime":"20161007205430"},{"dbid":0,"id":893968,"title":"11月试营 雷诺自动驾驶示范区落户武汉","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M07/6A/39/400x300_0_autohomecar__wKgH4Ff3YxqACJe-AAFqAImLz-o039.jpg","replycount":57,"pagecount":1,"jumppage":1,"lasttime":"20161008060000893968","newstype":0,"updatetime":"20161008090247"},{"dbid":0,"id":893970,"title":"新Q5/新5008等 巴黎车展将入华SUV盘点","mediatype":0,"type":"新闻中心","time":"2016-10-08","intacttime":"2016/10/8 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M03/6A/9A/400x300_0_autohomecar__wKgH5lf3oKWADii5AAHtFYQqmIY358.jpg","replycount":358,"pagecount":3,"jumppage":1,"lasttime":"20161008000000893970","newstype":0,"updatetime":"20161008094801"},{"dbid":0,"id":893965,"title":"或售6.39-7.99万 瑞虎3X疑似售价曝光","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M02/49/FB/400x300_0_autohomecar__wKgFWFf3NM-AcTbUAAF3g2FF8Mk597.jpg","replycount":929,"pagecount":1,"jumppage":1,"lasttime":"20161007200500893965","newstype":0,"updatetime":"20161007140356"},{"dbid":0,"id":893963,"title":"性能再提升？疑似AMG C 63 R Coupe谍照","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M00/65/1A/400x300_0_autohomecar__wKgH51f3F9uAab2iAAGUCfK3BtA674.jpg","replycount":316,"pagecount":1,"jumppage":1,"lasttime":"20161007200500893963","newstype":0,"updatetime":"20161007123301"},{"dbid":0,"id":893969,"title":"家用车新选择 北京现代悦纳实车到店","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 18:02:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M13/67/48/400x300_0_autohomecar__wKgH1lf3WzOAWePkAAHJ3vYX9zM583.jpg","replycount":637,"pagecount":1,"jumppage":1,"lasttime":"20161007180200893969","newstype":0,"updatetime":"20161008094639"},{"dbid":0,"id":893962,"title":"或命名Atlas 大众新SUV海外版更多信息","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 11:03:06","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/69/0F/400x300_0_autohomecar__wKjB0Ff3D4SAXJRfAAG2HanTlZI879.jpg","replycount":767,"pagecount":1,"jumppage":1,"lasttime":"20161007110306893962","newstype":0,"updatetime":"20161007110225"},{"dbid":0,"id":893961,"title":"外观内饰更时尚 曝帝豪百万纪念版实车","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 10:15:20","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/65/05/400x300_0_autohomecar__wKgH11f2-ziAQ6ERAAF7I-mg0ME404.jpg","replycount":928,"pagecount":1,"jumppage":1,"lasttime":"20161007101520893961","newstype":0,"updatetime":"20161007101422"},{"dbid":0,"id":893959,"title":"延续XC90设计 曝新沃尔沃XC60内饰谍照","mediatype":0,"type":"新闻中心","time":"2016-10-07","intacttime":"2016/10/7 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g12/M0F/62/A9/400x300_0_autohomecar__wKgH01f2A42ABEqKAAGcHwP7Q1U293.jpg","replycount":836,"pagecount":1,"jumppage":1,"lasttime":"20161007060100893959","newstype":0,"updatetime":"20161006155611"},{"dbid":0,"id":893958,"title":"造型更战斗 兰博基尼新款Aventador谍照","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M09/45/39/400x300_0_autohomecar__wKgFV1f18TqAPmlEAAG8pCPuvM8328.jpg","replycount":495,"pagecount":1,"jumppage":1,"lasttime":"20161006200500893958","newstype":0,"updatetime":"20161006145353"},{"dbid":0,"id":893957,"title":"限时限量发售 斯巴鲁WRX S4 tS官图发布","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 20:02:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M0C/48/22/400x300_0_autohomecar__wKjBwVf148WALHY3AAEM1DqrqPY203.jpg","replycount":343,"pagecount":1,"jumppage":1,"lasttime":"20161006200200893957","newstype":0,"updatetime":"20161007082710"},{"dbid":0,"id":893956,"title":"或定名哈弗H4S 哈弗全新SUV谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 10:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M04/47/E4/400x300_0_autohomecar__wKjBwVf1s76AdXldAAE86WrKVPw534.jpg","replycount":1556,"pagecount":1,"jumppage":1,"lasttime":"20161006101941893956","newstype":0,"updatetime":"20161006101719"},{"dbid":0,"id":893955,"title":"或采用对开门设计 曝疑似宝马i5专利图","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 9:14:32","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M06/46/B0/400x300_0_autohomecar__wKjBwlf1pGGAE5DqAACG5VLPJSA320.jpg","replycount":320,"pagecount":1,"jumppage":1,"lasttime":"20161006091432893955","newstype":0,"updatetime":"20161006092205"},{"dbid":0,"id":893952,"title":"或搭载1.6T发动机 玛驰NISMO假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-10-06","intacttime":"2016/10/6 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M11/66/3C/400x300_0_autohomecar__wKgH4Vf0ZBSAISwUAAF77q1eNrY075.jpg","replycount":458,"pagecount":1,"jumppage":1,"lasttime":"20161006060000893952","newstype":0,"updatetime":"20161005163601"},{"dbid":0,"id":893951,"title":"对手锁定A3 宝马1系三厢版2017年初上市","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M00/43/F7/400x300_0_autohomecar__wKgFVlf0WzWAQgSpAADM79it6ss651.jpg","replycount":1359,"pagecount":1,"jumppage":1,"lasttime":"20161005200500893951","newstype":0,"updatetime":"20161005094652"},{"dbid":0,"id":893953,"title":"四驱入门预售30万 曝冠道上市车型信息","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/47/E4/400x300_0_autohomecar__wKgFW1f0uqCAPq7MAAGDlcV_LyM581.jpg","replycount":2779,"pagecount":1,"jumppage":1,"lasttime":"20161005200000893953","newstype":0,"updatetime":"20161005163534"},{"dbid":0,"id":893950,"title":"2017年上市 曝大众Tiguan长轴距版谍照","mediatype":0,"type":"新闻中心","time":"2016-10-05","intacttime":"2016/10/5 9:23:54","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0A/62/56/400x300_0_autohomecar__wKgH11f0VdaATpFiAAFu2zWSHJE970.jpg","replycount":1242,"pagecount":1,"jumppage":1,"lasttime":"20161005092354893950","newstype":0,"updatetime":"20161005092346"}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        private List<?> focusimg;
        /**
         * dbid : 0
         * id : 894002
         * title : 您怎么看？北京网约车必须是京人京车
         * mediatype : 0
         * type : 新闻中心
         * time : 2016-10-08
         * intacttime : 2016/10/8 18:02:41
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g7/M01/67/69/400x300_0_autohomecar__wKgHzlf4v_2AamhXAAGCSRZ-6oI085.jpg
         * replycount : 408
         * pagecount : 1
         * jumppage : 1
         * lasttime : 20161008180241894002
         * newstype : 0
         * updatetime : 20161008180353
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<?> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<?> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class NewslistBean {
            private int dbid;
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String intacttime;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;

            public int getDbid() {
                return dbid;
            }

            public void setDbid(int dbid) {
                this.dbid = dbid;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIntacttime() {
                return intacttime;
            }

            public void setIntacttime(String intacttime) {
                this.intacttime = intacttime;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }
        }
    }
}
