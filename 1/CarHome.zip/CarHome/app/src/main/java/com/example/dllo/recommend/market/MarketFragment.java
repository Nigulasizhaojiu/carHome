package com.example.dllo.recommend.market;

import com.example.dllo.carhome.BaseFragment;
import com.example.dllo.carhome.R;

/**
 * Created by dllo on 16/9/30.
 */
public class MarketFragment extends BaseFragment{
    @Override
    protected int setLayout() {
        return R.layout.market_fragment;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
