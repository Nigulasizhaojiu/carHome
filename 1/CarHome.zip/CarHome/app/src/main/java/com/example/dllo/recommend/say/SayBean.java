package com.example.dllo.recommend.say;

import java.util.List;

/**
 * Created by dllo on 16/10/8.
 */
public class SayBean {

    /**
     * returncode : 0
     * message :
     * result : {"total":10821,"isloadmore":true,"list":[{"id":539276,"title":"双色车身，标致4008量产车型配置解读","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/6B/90/160x120_0_autohomecar__wKgH2lf4gwCAAjQTAAP-R0gNKF0537.jpg","replycount":41,"pagecount":1,"jumppage":1,"updatetime":"20161008132418","lastid":"20161008141000539276"},{"id":538416,"title":"05年开过的车 一汽奥迪A6 4.2 quattro","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M13/60/AD/160x120_0_autohomecar__wKgH3lfrqreATuBxAADRUiu4j3E352.jpg","replycount":29,"pagecount":1,"jumppage":1,"updatetime":"20161008140109","lastid":"20161008130000538416"},{"id":539172,"title":"东风自研发动机 但底盘却仍用日系车的","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M03/6A/76/160x120_0_autohomecar__wKgH3Ff4YaqAfhTnAAJ0R4O7rZc301.jpg","replycount":309,"pagecount":1,"jumppage":1,"updatetime":"20161008112111","lastid":"20161008120000539172"},{"id":539271,"title":"拨片换挡究竟用处有多大？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M08/6B/05/160x120_0_autohomecar__wKgH2lf4QUyAZef2AAHHPMLhboY036.jpg","replycount":251,"pagecount":1,"jumppage":1,"updatetime":"20161008110557","lastid":"20161008113500539271"},{"id":539303,"title":"捷豹路虎9月全球销量增28.2% 国车占5成","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M03/65/DC/160x120_0_autohomecar__wKgH1Vf4Y7GAVzS1AAKv7X2KYVs833.jpg","replycount":324,"pagecount":1,"jumppage":1,"updatetime":"20161008111042","lastid":"20161008111000539303"},{"id":539251,"title":"消费升级、更迭，小型车已成明日黄花？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M03/4A/8C/160x120_0_autohomecar__wKjBxFf4S2SAc6mNAARM6Dr4wzM592.jpg","replycount":216,"pagecount":1,"jumppage":1,"updatetime":"20161008092702","lastid":"20161008104000539251"},{"id":539273,"title":"差价6000元 帝豪GL离卡罗拉有多远？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M08/46/A3/160x120_0_autohomecar__wKgFVVf4U4-AOOP5AAFYUhVwruU332.jpg","replycount":1055,"pagecount":1,"jumppage":1,"updatetime":"20161008100153","lastid":"20161008100000539273"},{"id":539257,"title":"13-17万中端SUV在等待和呼唤自己的项羽","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/24/160x120_0_autohomecar__wKgFWFf4SDGAC4puAAPb7rOig4Q673.jpg","replycount":100,"pagecount":1,"jumppage":1,"updatetime":"20161008091322","lastid":"20161008093500539257"},{"id":539236,"title":"修完就卖？卖家为何如此迫不及待！","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M03/69/D1/160x120_0_autohomecar__wKgH4Ff3IrKAVayrADBDLJIvHRA517.JPG","replycount":153,"pagecount":1,"jumppage":1,"updatetime":"20161007161915","lastid":"20161008090000539236"},{"id":531667,"title":"【黑知识讲堂】有了Turbo还要VTEC吗？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M06/69/0A/160x120_0_autohomecar__wKjB0Vf3stKAA_2VAAFLKhvkETQ485.jpg","replycount":293,"pagecount":1,"jumppage":1,"updatetime":"20161007223604","lastid":"20161008083000531667"},{"id":539206,"title":"韩系动向，看韩系车前三季度销量如何","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/65/43/160x120_0_autohomecar__wKgH1Ff3B8mAM8EMAANn1SivonM997.jpg","replycount":527,"pagecount":1,"jumppage":1,"updatetime":"20161007162706","lastid":"20161008073000539206"},{"id":538717,"title":"汽车江湖十五回:路虎发现5是神行Plus吗","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M05/46/41/160x120_0_autohomecar__wKgFV1f3BLqAQzrNAACAr0o74kc286.jpg","replycount":253,"pagecount":1,"jumppage":1,"updatetime":"20161008112808","lastid":"20161008060600538717"},{"id":537732,"title":"三缸时代来临？盘点未来您的三缸座驾！","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g7/M09/69/A3/160x120_0_autohomecar__wKjB0Ff3Y3uAEqokAAFDUffHGus132.jpg","replycount":288,"pagecount":1,"jumppage":1,"updatetime":"20161007165740","lastid":"20161008010100537732"},{"id":532134,"title":"为何A6L/5系卖30多万 奔驰E级还是能赢","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M01/0D/F7/160x120_0_autohomecar__wKgH0Ve7lGGAZfLqAATGCLlRNuQ028.jpg","replycount":1124,"pagecount":1,"jumppage":1,"updatetime":"20161007224045","lastid":"20161008000100532134"},{"id":539229,"title":"阿鲁的觉醒，铃木大R迎来重大换代！","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M04/68/77/160x120_0_autohomecar__wKgHz1f3EGWAa-mmAALQwlNIM88335.jpg","replycount":232,"pagecount":1,"jumppage":1,"updatetime":"20161007222848","lastid":"20161007223000539229"},{"id":538624,"title":"爷爷玩GT，爸爸也玩GT，谁的GT最牛？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M0E/5C/56/160x120_0_autohomecar__wKgH0lftIBqAGDBIAAJUP6Sg7SQ381.PNG","replycount":57,"pagecount":1,"jumppage":1,"updatetime":"20161008092625","lastid":"20161007220000538624"},{"id":538171,"title":"试驾--特斯拉MODEL X,不止于让超跑吃灰","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/66/82/160x120_0_autohomecar__wKgH0lf3rEmAD_ZgAAC9xdvRfMQ422.jpg","replycount":251,"pagecount":1,"jumppage":1,"updatetime":"20161007220811","lastid":"20161007213000538171"},{"id":539205,"title":"国产会加长轴距吗？解读全新一代奥迪Q5","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M14/6B/F1/160x120_0_autohomecar__wKgH3lf2Z8qALzpKAAD-MeTEL8I912.jpg","replycount":497,"pagecount":1,"jumppage":1,"updatetime":"20161006230352","lastid":"20161007210000539205"},{"id":535677,"title":"神龙增长乏力 车市退步生怎么打翻身仗","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0A/69/C1/160x120_0_autohomecar__wKgH4Vf3aFGAAMoAAAEIbKaBEsI188.jpg","replycount":710,"pagecount":1,"jumppage":1,"updatetime":"20161007172033","lastid":"20161007203000535677"},{"id":536170,"title":"赛车差速器和我们家用车的有什么不同？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M0B/46/39/160x120_0_autohomecar__wKgH21fZgriAD-UtAAKjhxxtcqk416.jpg","replycount":71,"pagecount":1,"jumppage":1,"updatetime":"20161007170749","lastid":"20161007200000536170"},{"id":538350,"title":"商业报告丨中国品牌车主换购忠诚度调查","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M0A/6A/DC/160x120_0_autohomecar__wKgH21f3YJaAbGD7AAEI6wavENo025.jpg","replycount":740,"pagecount":1,"jumppage":1,"updatetime":"20161007164512","lastid":"20161007190000538350"},{"id":539228,"title":"Trakka Trakkadu AT宿营车试驾","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/46/CB/160x120_0_autohomecar__wKgFVlf3EBWACFWeACvvvkl1MKM048.jpg","replycount":39,"pagecount":1,"jumppage":1,"updatetime":"20161007160720","lastid":"20161007180000539228"},{"id":539234,"title":"叫板大众丰田 吉利全新高端L品牌将发布","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M01/6C/8D/160x120_0_autohomecar__wKgH3lf3JmWAaoloAACFSgFddRM030.jpg","replycount":1864,"pagecount":1,"jumppage":1,"updatetime":"20161007163242","lastid":"20161007170000539234"},{"id":539166,"title":"奥迪全新A4L能否夺回豪华中型车头牌？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/67/D2/160x120_0_autohomecar__wKgH5lf1NGCAPh_mAAMCTqz2KPc480.jpg","replycount":949,"pagecount":1,"jumppage":1,"updatetime":"20161007103708","lastid":"20161007160000539166"},{"id":539219,"title":"2016年度最佳拉力摩托车花落谁家？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M0B/62/15/160x120_0_autohomecar__wKjBz1f3BbGAQkFtAAFygs692L0068.jpg","replycount":135,"pagecount":1,"jumppage":1,"updatetime":"20161007101731","lastid":"20161007150000539219"},{"id":539226,"title":"胡哥说制动 重卡ABS齿圈脏了该怎么办","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M11/65/14/160x120_0_autohomecar__wKgH0Vf3AgOALjugAAsDGSFOzLo599.jpg","replycount":111,"pagecount":1,"jumppage":1,"updatetime":"20161007104306","lastid":"20161007140000539226"},{"id":538805,"title":"10年奥迪A6L各种毛病！白菜价格！","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M11/64/BE/160x120_0_autohomecar__wKgH31fuH9uAGZjjADrjmC4PwxY890.JPG","replycount":1407,"pagecount":1,"jumppage":1,"updatetime":"20161006095254","lastid":"20161007130000538805"},{"id":539211,"title":"雅阁混动值不值？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0A/48/33/160x120_0_autohomecar__wKjBw1f2SKSAEBtCAATpf270fII749.jpg","replycount":821,"pagecount":1,"jumppage":1,"updatetime":"20161007105037","lastid":"20161007120000539211"},{"id":537718,"title":"雷克萨斯很好，为何我们仍喜欢奔驰宝马","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/54/E4/160x120_0_autohomecar__wKjByVfmXx-AKbESAAi_10fqygI863.jpg","replycount":1814,"pagecount":1,"jumppage":1,"updatetime":"20160926110247","lastid":"20161007110000537718"},{"id":537839,"title":"鸿沟难平，中国品牌向上质变有多难？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M14/59/30/160x120_0_autohomecar__wKgH41foci2AFYghAAEQXKmMVNA293.jpg","replycount":583,"pagecount":1,"jumppage":1,"updatetime":"20161006150726","lastid":"20161007100000537839"}]}
     */

    private int returncode;
    private String message;
    /**
     * total : 10821
     * isloadmore : true
     * list : [{"id":539276,"title":"双色车身，标致4008量产车型配置解读","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/6B/90/160x120_0_autohomecar__wKgH2lf4gwCAAjQTAAP-R0gNKF0537.jpg","replycount":41,"pagecount":1,"jumppage":1,"updatetime":"20161008132418","lastid":"20161008141000539276"},{"id":538416,"title":"05年开过的车 一汽奥迪A6 4.2 quattro","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M13/60/AD/160x120_0_autohomecar__wKgH3lfrqreATuBxAADRUiu4j3E352.jpg","replycount":29,"pagecount":1,"jumppage":1,"updatetime":"20161008140109","lastid":"20161008130000538416"},{"id":539172,"title":"东风自研发动机 但底盘却仍用日系车的","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M03/6A/76/160x120_0_autohomecar__wKgH3Ff4YaqAfhTnAAJ0R4O7rZc301.jpg","replycount":309,"pagecount":1,"jumppage":1,"updatetime":"20161008112111","lastid":"20161008120000539172"},{"id":539271,"title":"拨片换挡究竟用处有多大？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M08/6B/05/160x120_0_autohomecar__wKgH2lf4QUyAZef2AAHHPMLhboY036.jpg","replycount":251,"pagecount":1,"jumppage":1,"updatetime":"20161008110557","lastid":"20161008113500539271"},{"id":539303,"title":"捷豹路虎9月全球销量增28.2% 国车占5成","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M03/65/DC/160x120_0_autohomecar__wKgH1Vf4Y7GAVzS1AAKv7X2KYVs833.jpg","replycount":324,"pagecount":1,"jumppage":1,"updatetime":"20161008111042","lastid":"20161008111000539303"},{"id":539251,"title":"消费升级、更迭，小型车已成明日黄花？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M03/4A/8C/160x120_0_autohomecar__wKjBxFf4S2SAc6mNAARM6Dr4wzM592.jpg","replycount":216,"pagecount":1,"jumppage":1,"updatetime":"20161008092702","lastid":"20161008104000539251"},{"id":539273,"title":"差价6000元 帝豪GL离卡罗拉有多远？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M08/46/A3/160x120_0_autohomecar__wKgFVVf4U4-AOOP5AAFYUhVwruU332.jpg","replycount":1055,"pagecount":1,"jumppage":1,"updatetime":"20161008100153","lastid":"20161008100000539273"},{"id":539257,"title":"13-17万中端SUV在等待和呼唤自己的项羽","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/4B/24/160x120_0_autohomecar__wKgFWFf4SDGAC4puAAPb7rOig4Q673.jpg","replycount":100,"pagecount":1,"jumppage":1,"updatetime":"20161008091322","lastid":"20161008093500539257"},{"id":539236,"title":"修完就卖？卖家为何如此迫不及待！","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M03/69/D1/160x120_0_autohomecar__wKgH4Ff3IrKAVayrADBDLJIvHRA517.JPG","replycount":153,"pagecount":1,"jumppage":1,"updatetime":"20161007161915","lastid":"20161008090000539236"},{"id":531667,"title":"【黑知识讲堂】有了Turbo还要VTEC吗？","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M06/69/0A/160x120_0_autohomecar__wKjB0Vf3stKAA_2VAAFLKhvkETQ485.jpg","replycount":293,"pagecount":1,"jumppage":1,"updatetime":"20161007223604","lastid":"20161008083000531667"},{"id":539206,"title":"韩系动向，看韩系车前三季度销量如何","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/65/43/160x120_0_autohomecar__wKgH1Ff3B8mAM8EMAANn1SivonM997.jpg","replycount":527,"pagecount":1,"jumppage":1,"updatetime":"20161007162706","lastid":"20161008073000539206"},{"id":538717,"title":"汽车江湖十五回:路虎发现5是神行Plus吗","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M05/46/41/160x120_0_autohomecar__wKgFV1f3BLqAQzrNAACAr0o74kc286.jpg","replycount":253,"pagecount":1,"jumppage":1,"updatetime":"20161008112808","lastid":"20161008060600538717"},{"id":537732,"title":"三缸时代来临？盘点未来您的三缸座驾！","time":"2016-10-08","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g7/M09/69/A3/160x120_0_autohomecar__wKjB0Ff3Y3uAEqokAAFDUffHGus132.jpg","replycount":288,"pagecount":1,"jumppage":1,"updatetime":"20161007165740","lastid":"20161008010100537732"},{"id":532134,"title":"为何A6L/5系卖30多万 奔驰E级还是能赢","time":"2016-10-08","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M01/0D/F7/160x120_0_autohomecar__wKgH0Ve7lGGAZfLqAATGCLlRNuQ028.jpg","replycount":1124,"pagecount":1,"jumppage":1,"updatetime":"20161007224045","lastid":"20161008000100532134"},{"id":539229,"title":"阿鲁的觉醒，铃木大R迎来重大换代！","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M04/68/77/160x120_0_autohomecar__wKgHz1f3EGWAa-mmAALQwlNIM88335.jpg","replycount":232,"pagecount":1,"jumppage":1,"updatetime":"20161007222848","lastid":"20161007223000539229"},{"id":538624,"title":"爷爷玩GT，爸爸也玩GT，谁的GT最牛？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M0E/5C/56/160x120_0_autohomecar__wKgH0lftIBqAGDBIAAJUP6Sg7SQ381.PNG","replycount":57,"pagecount":1,"jumppage":1,"updatetime":"20161008092625","lastid":"20161007220000538624"},{"id":538171,"title":"试驾--特斯拉MODEL X,不止于让超跑吃灰","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/66/82/160x120_0_autohomecar__wKgH0lf3rEmAD_ZgAAC9xdvRfMQ422.jpg","replycount":251,"pagecount":1,"jumppage":1,"updatetime":"20161007220811","lastid":"20161007213000538171"},{"id":539205,"title":"国产会加长轴距吗？解读全新一代奥迪Q5","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M14/6B/F1/160x120_0_autohomecar__wKgH3lf2Z8qALzpKAAD-MeTEL8I912.jpg","replycount":497,"pagecount":1,"jumppage":1,"updatetime":"20161006230352","lastid":"20161007210000539205"},{"id":535677,"title":"神龙增长乏力 车市退步生怎么打翻身仗","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0A/69/C1/160x120_0_autohomecar__wKgH4Vf3aFGAAMoAAAEIbKaBEsI188.jpg","replycount":710,"pagecount":1,"jumppage":1,"updatetime":"20161007172033","lastid":"20161007203000535677"},{"id":536170,"title":"赛车差速器和我们家用车的有什么不同？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M0B/46/39/160x120_0_autohomecar__wKgH21fZgriAD-UtAAKjhxxtcqk416.jpg","replycount":71,"pagecount":1,"jumppage":1,"updatetime":"20161007170749","lastid":"20161007200000536170"},{"id":538350,"title":"商业报告丨中国品牌车主换购忠诚度调查","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M0A/6A/DC/160x120_0_autohomecar__wKgH21f3YJaAbGD7AAEI6wavENo025.jpg","replycount":740,"pagecount":1,"jumppage":1,"updatetime":"20161007164512","lastid":"20161007190000538350"},{"id":539228,"title":"Trakka Trakkadu AT宿营车试驾","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/46/CB/160x120_0_autohomecar__wKgFVlf3EBWACFWeACvvvkl1MKM048.jpg","replycount":39,"pagecount":1,"jumppage":1,"updatetime":"20161007160720","lastid":"20161007180000539228"},{"id":539234,"title":"叫板大众丰田 吉利全新高端L品牌将发布","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M01/6C/8D/160x120_0_autohomecar__wKgH3lf3JmWAaoloAACFSgFddRM030.jpg","replycount":1864,"pagecount":1,"jumppage":1,"updatetime":"20161007163242","lastid":"20161007170000539234"},{"id":539166,"title":"奥迪全新A4L能否夺回豪华中型车头牌？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/67/D2/160x120_0_autohomecar__wKgH5lf1NGCAPh_mAAMCTqz2KPc480.jpg","replycount":949,"pagecount":1,"jumppage":1,"updatetime":"20161007103708","lastid":"20161007160000539166"},{"id":539219,"title":"2016年度最佳拉力摩托车花落谁家？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M0B/62/15/160x120_0_autohomecar__wKjBz1f3BbGAQkFtAAFygs692L0068.jpg","replycount":135,"pagecount":1,"jumppage":1,"updatetime":"20161007101731","lastid":"20161007150000539219"},{"id":539226,"title":"胡哥说制动 重卡ABS齿圈脏了该怎么办","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M11/65/14/160x120_0_autohomecar__wKgH0Vf3AgOALjugAAsDGSFOzLo599.jpg","replycount":111,"pagecount":1,"jumppage":1,"updatetime":"20161007104306","lastid":"20161007140000539226"},{"id":538805,"title":"10年奥迪A6L各种毛病！白菜价格！","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M11/64/BE/160x120_0_autohomecar__wKgH31fuH9uAGZjjADrjmC4PwxY890.JPG","replycount":1407,"pagecount":1,"jumppage":1,"updatetime":"20161006095254","lastid":"20161007130000538805"},{"id":539211,"title":"雅阁混动值不值？","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0A/48/33/160x120_0_autohomecar__wKjBw1f2SKSAEBtCAATpf270fII749.jpg","replycount":821,"pagecount":1,"jumppage":1,"updatetime":"20161007105037","lastid":"20161007120000539211"},{"id":537718,"title":"雷克萨斯很好，为何我们仍喜欢奔驰宝马","time":"2016-10-07","type":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/54/E4/160x120_0_autohomecar__wKjByVfmXx-AKbESAAi_10fqygI863.jpg","replycount":1814,"pagecount":1,"jumppage":1,"updatetime":"20160926110247","lastid":"20161007110000537718"},{"id":537839,"title":"鸿沟难平，中国品牌向上质变有多难？","time":"2016-10-07","type":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M14/59/30/160x120_0_autohomecar__wKgH41foci2AFYghAAEQXKmMVNA293.jpg","replycount":583,"pagecount":1,"jumppage":1,"updatetime":"20161006150726","lastid":"20161007100000537839"}]
     */

    private ResultBean result;

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int total;
        private boolean isloadmore;
        /**
         * id : 539276
         * title : 双色车身，标致4008量产车型配置解读
         * time : 2016-10-08
         * type :
         * smallpic : http://www3.autoimg.cn/newsdfs/g4/M06/6B/90/160x120_0_autohomecar__wKgH2lf4gwCAAjQTAAP-R0gNKF0537.jpg
         * replycount : 41
         * pagecount : 1
         * jumppage : 1
         * updatetime : 20161008132418
         * lastid : 20161008141000539276
         */

        private List<ListBean> list;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int id;
            private String title;
            private String time;
            private String type;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String updatetime;
            private String lastid;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public String getLastid() {
                return lastid;
            }

            public void setLastid(String lastid) {
                this.lastid = lastid;
            }
        }
    }
}
